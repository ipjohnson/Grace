﻿using Grace.DependencyInjection.Attributes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.Classes.Attributed
{
	public interface IComplexService
	{
		void Validate();
	}

	[Export(typeof(IComplexService))]
	public class ComplexService : IComplexService
	{
		private bool activationCalled;
		private bool importMethodCalled;

		public ComplexService(IAttributeBasicService basicService)
		{
			Assert.IsNotNull(basicService);
		}

		[Import]
		public IAttributeImportConstructorService ImportConstructorService { get; set; }

		public void Validate()
		{
			Assert.IsTrue(importMethodCalled);
			Assert.IsTrue(activationCalled);
		}

		[Import]
		public void ImportMethod(IAttributedImportPropertyService propertyService)
		{
			Assert.IsNotNull(propertyService);

			importMethodCalled = true;
		}

		[ActivationComplete]
		public void Activation()
		{
			activationCalled = true;
		}
	}
}