﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.Classes.Simple
{
	public interface IImportArrayService
	{
	}

	public class ImportArrayService : IImportArrayService
	{
		public ImportArrayService(ISimpleObject[] simpleObjects)
		{
			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Length);
		}
	}
}