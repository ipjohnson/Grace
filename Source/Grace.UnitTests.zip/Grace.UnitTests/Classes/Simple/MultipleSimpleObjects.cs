﻿namespace Grace.UnitTests.Classes.Simple
{
	public interface ISimpleObject
	{
	}

	public class SimpleObjectA : ISimpleObject
	{
	}

	public class SimpleObjectB : ISimpleObject
	{
	}

	public class SimpleObjectC : ISimpleObject
	{
	}

	public class SimpleObjectD : ISimpleObject
	{
	}

	public class SimpleObjectE : ISimpleObject
	{
	}
}