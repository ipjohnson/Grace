﻿using System;

namespace Grace.UnitTests.Classes.Simple
{
	public class SomeTestAttribute : Attribute
	{
		public int TestValue { get; set; }
	}
}