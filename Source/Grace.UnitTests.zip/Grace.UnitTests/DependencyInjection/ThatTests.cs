﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Attributed;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection
{
	[TestClass]
	public class ThatTests
	{
		[TestMethod]
		public void AreInTheSameNamespace()
		{
			Func<Type, bool> sameNamespace = TypesThat.AreInTheSameNamespaceAs(typeof(DependencyInjectionContainer));

			Assert.IsTrue(sameNamespace(typeof(TypesThat)));

			Assert.IsFalse(sameNamespace(typeof(BlackList)));

			Assert.IsFalse(sameNamespace(GetType()));
		}

		[TestMethod]
		public void AreInTheSameNamespaceAndSubnamespace()
		{
			Func<Type, bool> sameNamespace = TypesThat.AreInTheSameNamespaceAs(typeof(DependencyInjectionContainer), true);

			Assert.IsTrue(sameNamespace(typeof(TypesThat)));

			Assert.IsTrue(sameNamespace(typeof(BlackList)));

			Assert.IsFalse(sameNamespace(GetType()));
		}

		[TestMethod]
		public void AreInTheSameNamespaceGeneric()
		{
			Func<Type, bool> sameNamespace = TypesThat.AreInTheSameNamespaceAs<DependencyInjectionContainer>();

			Assert.IsTrue(sameNamespace(typeof(TypesThat)));

			Assert.IsFalse(sameNamespace(typeof(BlackList)));

			Assert.IsFalse(sameNamespace(GetType()));
		}

		[TestMethod]
		public void AreInTheSameNamespaceAndSubnamespaceGeneric()
		{
			Func<Type, bool> sameNamespace = TypesThat.AreInTheSameNamespaceAs<DependencyInjectionContainer>(true);

			Assert.IsTrue(sameNamespace(typeof(TypesThat)));

			Assert.IsTrue(sameNamespace(typeof(BlackList)));

			Assert.IsFalse(sameNamespace(GetType()));
		}

		[TestMethod]
		public void HaveAttributeType()
		{
			Func<Type, bool> haveFilter = TypesThat.HaveAttribute(typeof(SomeTestAttribute));

			Assert.IsTrue(haveFilter(typeof(AttributedSimpleObjectA)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectE)));
		}

		[TestMethod]
		public void HaveAttributeTypeFiltered()
		{
			Func<Type, bool> haveFilter = TypesThat.HaveAttribute(typeof(SomeTestAttribute),
				x => ((SomeTestAttribute)x).TestValue == 5);

			Assert.IsTrue(haveFilter(typeof(AttributedSimpleObjectA)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectB)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectE)));
		}

		[TestMethod]
		public void HaveAttributeGeneric()
		{
			Func<Type, bool> haveFilter = TypesThat.HaveAttribute(typeof(SomeTestAttribute));

			Assert.IsTrue(haveFilter(typeof(AttributedSimpleObjectA)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectE)));
		}

		[TestMethod]
		public void HaveAttributeGenericFiltered()
		{
			Func<Type, bool> haveFilter = TypesThat.HaveAttribute<SomeTestAttribute>(x => x.TestValue == 5);

			Assert.IsTrue(haveFilter(typeof(AttributedSimpleObjectA)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectB)));

			Assert.IsFalse(haveFilter(typeof(AttributedSimpleObjectE)));
		}

		[TestMethod]
		public void ComplexHaveAttribute()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export(Types.FromThisAssembly()).
				ExportInterface(typeof(IAttributedSimpleObject)).
				Select(TypesThat.HaveAttribute<SomeTestAttribute>()));

			IEnumerable<IAttributedSimpleObject> simpleObjects = container.LocateAll<IAttributedSimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(3, simpleObjects.Count());
		}

		[TestMethod]
		public void ComplexHaveAttributeFiltered()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export(Types.FromThisAssembly()).
				ExportInterface(typeof(IAttributedSimpleObject)).
				Select(TypesThat.HaveAttribute<SomeTestAttribute>(x => x.TestValue == 5)));

			IEnumerable<IAttributedSimpleObject> simpleObjects = container.LocateAll<IAttributedSimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(1, simpleObjects.Count());
		}
	}
}