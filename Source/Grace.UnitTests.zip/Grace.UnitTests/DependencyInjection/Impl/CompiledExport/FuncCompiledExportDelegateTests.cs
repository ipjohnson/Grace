﻿using System;
using System.Reflection;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Exceptions;
using Grace.DependencyInjection.Impl;
using Grace.DependencyInjection.Impl.CompiledExport;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl.CompiledExport
{
	[TestClass]
	public class FuncCompiledExportDelegateTests
	{
		[TestMethod]
		public void SimpleExportTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(IBasicService),
				                                  Attributes = new Attribute[0]
			                                  };

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new BasicService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);
			Assert.IsInstanceOfType(activationDelegate(new FauxInjectionScope(), new FauxInjectionContext()),
				typeof(BasicService));
		}

		[TestMethod]
		public void ImportPropertyRootTransientTest()
		{
			FauxExportStrategy basicService = new FauxExportStrategy(() => new BasicService())
			                                  {
				                                  ExportNames = new[] { typeof(IBasicService).FullName }
			                                  };

			FauxInjectionScope injectionScope = new FauxInjectionScope();

			injectionScope.AddStrategy(basicService);

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportPropertyService),
				                                  IsTransient = true,
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportProperty(new ImportPropertyInfo
			                    {
				                    Property =
					                    typeof(ImportPropertyService).GetProperty("BasicService")
			                    });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportPropertyService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			IImportPropertyService propertyService =
				(IImportPropertyService)activationDelegate(injectionScope, new InjectionContext(null, injectionScope));

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void ImportPropertyRootNonTransientTest()
		{
			FauxExportStrategy basicService = new FauxExportStrategy(() => new BasicService())
			                                  {
				                                  ExportNames = new[] { typeof(IBasicService).FullName }
			                                  };

			FauxInjectionScope injectionScope = new FauxInjectionScope();

			injectionScope.AddStrategy(basicService);

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportPropertyService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportProperty(new ImportPropertyInfo
			                    {
				                    Property =
					                    typeof(ImportPropertyService).GetProperty("BasicService")
			                    });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportPropertyService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			IImportPropertyService propertyService =
				(IImportPropertyService)activationDelegate(injectionScope, new InjectionContext(null, injectionScope));

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void ImportPropertyNonRootTransienTest()
		{
			FauxExportStrategy basicService = new FauxExportStrategy(() => new BasicService())
			                                  {
				                                  ExportNames = new[] { typeof(IBasicService).FullName }
			                                  };

			InjectionKernelManager manager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionScope =
				new InjectionKernel(manager, null, null, "Root", DependencyInjectionContainer.CompareExportStrategies);

			injectionScope.AddStrategy(basicService);

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportPropertyService),
				                                  IsTransient = true,
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportProperty(new ImportPropertyInfo
			                    {
				                    Property =
					                    typeof(ImportPropertyService).GetProperty("BasicService")
			                    });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportPropertyService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			IInjectionScope requestingScope = injectionScope.CreateChildScope();

			IImportPropertyService propertyService =
				(IImportPropertyService)activationDelegate(injectionScope, new InjectionContext(null, requestingScope));

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void ImportPropertyNonRootNonTransienTest()
		{
			FauxExportStrategy basicService = new FauxExportStrategy(() => new BasicService())
			                                  {
				                                  ExportNames = new[] { typeof(IBasicService).FullName }
			                                  };

			FauxInjectionScope injectionScope = new FauxInjectionScope();

			injectionScope.AddStrategy(basicService);

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportPropertyService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportProperty(new ImportPropertyInfo
			                    {
				                    Property =
					                    typeof(ImportPropertyService).GetProperty("BasicService")
			                    });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportPropertyService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			IImportPropertyService propertyService =
				(IImportPropertyService)activationDelegate(injectionScope, new InjectionContext(null, injectionScope));

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void PropertyImportProviderTest()
		{
			FauxInjectionScope injectionScope = new FauxInjectionScope();

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportPropertyService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportProperty(new ImportPropertyInfo
			                    {
				                    Property = typeof(ImportPropertyService).GetProperty("BasicService"),
				                    ValueProvider = new FuncWithContextValueProvider<IBasicService>(context => new BasicService())
			                    });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportPropertyService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			IImportPropertyService propertyService =
				(IImportPropertyService)activationDelegate(injectionScope, new InjectionContext(null, injectionScope));

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void ImportMethodTest()
		{
			FauxExportStrategy basicService = new FauxExportStrategy(() => new BasicService())
			                                  {
				                                  ExportNames = new[] { typeof(IBasicService).FullName }
			                                  };

			FauxInjectionScope injectionScope = new FauxInjectionScope();

			injectionScope.AddStrategy(basicService);

			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ImportMethodService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.ImportMethod(new ImportMethodInfo
			                  {
				                  MethodToImport =
					                  typeof(ImportMethodService).GetRuntimeMethod("ImportMethod", new[] { typeof(IBasicService) })
			                  });

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ImportMethodService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			ImportMethodService propertyService =
				(ImportMethodService)activationDelegate(injectionScope, new InjectionContext(null, injectionScope));

			Assert.IsNotNull(propertyService);
		}

		[TestMethod]
		public void SimpleActivationMethodTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ActivateService),
				                                  IsTransient = true,
				                                  TrackDisposable = true,
				                                  Attributes = new Attribute[0]
			                                  };

			info.ActivateMethod(typeof(ActivateService).GetMethod("SimpleActivate"));

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ActivateService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			ActivateService activateService =
				(ActivateService)activationDelegate(new FauxInjectionScope(), new FauxInjectionContext());

			Assert.IsNotNull(activateService);
			Assert.IsTrue(activateService.SimpleActivateCalled);
			Assert.IsFalse(activateService.InjectionContextActivateCalled);
		}

		[TestMethod]
		public void InjectionContextActivationMethodTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ActivateService),
				                                  IsTransient = true,
				                                  TrackDisposable = true,
				                                  Attributes = new Attribute[0]
			                                  };

			info.ActivateMethod(typeof(ActivateService).GetMethod("InjectionContextActivate"));

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ActivateService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			ActivateService activateService =
				(ActivateService)activationDelegate(new FauxInjectionScope(), new FauxInjectionContext());

			Assert.IsNotNull(activateService);
			Assert.IsFalse(activateService.SimpleActivateCalled);
			Assert.IsTrue(activateService.InjectionContextActivateCalled);
		}

		[TestMethod]
		public void MultipleActivateTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(ActivateService),
				                                  IsTransient = true,
				                                  TrackDisposable = true,
				                                  Attributes = new Attribute[0]
			                                  };

			info.ActivateMethod(typeof(ActivateService).GetMethod("InjectionContextActivate"));
			info.ActivateMethod(typeof(ActivateService).GetMethod("SimpleActivate"));

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new ActivateService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			ActivateService activateService =
				(ActivateService)activationDelegate(new FauxInjectionScope(), new FauxInjectionContext());

			Assert.IsNotNull(activateService);
			Assert.IsTrue(activateService.SimpleActivateCalled);
			Assert.IsTrue(activateService.InjectionContextActivateCalled);
		}

		[TestMethod]
		public void EnrichWithTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(IBasicService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.EnrichWithDelegate((scope, context, injectObject) => new EnrichContainer(injectObject));

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new BasicService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);
			EnrichContainer container =
				(EnrichContainer)activationDelegate(new FauxInjectionScope(), new FauxInjectionContext());

			Assert.IsNotNull(container);
			Assert.IsNotNull(container.EnrichedObject);
			Assert.IsInstanceOfType(container.EnrichedObject, typeof(BasicService));
		}

		[TestMethod]
		public void MultipleEnrichWithTest()
		{
			CompiledExportDelegateInfo info = new CompiledExportDelegateInfo
			                                  {
				                                  ActivationType = typeof(IBasicService),
				                                  Attributes = new Attribute[0]
			                                  };

			info.EnrichWithDelegate((scope, context, injectObject) => new EnrichContainer(injectObject));
			info.EnrichWithDelegate((scope, context, injectObject) => new EnrichContainer(injectObject));

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new BasicService(), new FauxInjectionScope());

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);
			EnrichContainer container =
				(EnrichContainer)activationDelegate(new FauxInjectionScope(), new FauxInjectionContext());

			Assert.IsNotNull(container);
			Assert.IsNotNull(container.EnrichedObject);

			EnrichContainer nestedContainer = (EnrichContainer)container.EnrichedObject;

			Assert.IsNotNull(nestedContainer.EnrichedObject);
			Assert.IsInstanceOfType(nestedContainer.EnrichedObject, typeof(BasicService));
		}

		[TestMethod]
		public void DisposalTest()
		{
			FauxInjectionScope injectionScope = new FauxInjectionScope();

			CompiledExportDelegateInfo info =
				new CompiledExportDelegateInfo
				{
					ActivationType = typeof(DisposableService),
					IsTransient = true,
					TrackDisposable = true,
					Attributes = new Attribute[0]
				};

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new DisposableService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			FauxInjectionContext context = new FauxInjectionContext
			                               {
				                               DisposalScope = new DisposalScope()
			                               };

			IDisposableService disposableService = (IDisposableService)activationDelegate(injectionScope, context);

			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			context.DisposalScope.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void MissingDisposalScopeTest()
		{
			FauxInjectionScope injectionScope = new FauxInjectionScope();

			CompiledExportDelegateInfo info =
				new CompiledExportDelegateInfo
				{
					ActivationType = typeof(DisposableService),
					IsTransient = true,
					TrackDisposable = true,
					Attributes = new Attribute[0]
				};

			FuncCompiledExportDelegate compiledExport =
				new FuncCompiledExportDelegate(info, (x, y) => new DisposableService(), injectionScope);

			ExportActivationDelegate activationDelegate = compiledExport.CompileDelegate();

			Assert.IsNotNull(activationDelegate);

			FauxInjectionContext context = new FauxInjectionContext();

			try
			{
				IDisposableService disposableService = (IDisposableService)activationDelegate(injectionScope, context);

				throw new Exception("Should have thrown a DisposalScopeMissingException");
			}
			catch (DisposalScopeMissingException)
			{
			}
		}
	}
}