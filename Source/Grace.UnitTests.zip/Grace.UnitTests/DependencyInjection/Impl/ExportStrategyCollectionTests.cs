﻿using System.Collections.Generic;
using System.Linq;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class ExportStrategyCollectionTests
	{
		[TestMethod]
		public void ActivateTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => 5));

			Assert.AreEqual(5, collection.Activate(null, null, new FauxInjectionContext(), null));
		}

		[TestMethod]
		public void DisposeTwiceTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => 5));

			collection.Dispose();

			collection.Dispose();
		}

		[TestMethod]
		public void RemoveTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy tenExport = new FauxExportStrategy(() => 10) { Priority = 10 };

			collection.AddExport(new FauxExportStrategy(() => 5) { Priority = 5 });
			collection.AddExport(tenExport);
			collection.AddExport(new FauxExportStrategy(() => 1) { Priority = 1 });

			Assert.AreEqual(10, collection.Activate(null, null, new FauxInjectionContext(), null));

			collection.RemoveExport(tenExport);

			Assert.AreEqual(5, collection.Activate(null, null, new FauxInjectionContext(), null));
			Assert.AreEqual(2, collection.ActivateAll<int>(new FauxInjectionContext(), null).Count());
		}

		[TestMethod]
		public void PrioritySortTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => 5) { Priority = 5 });
			collection.AddExport(new FauxExportStrategy(() => 10) { Priority = 10 });
			collection.AddExport(new FauxExportStrategy(() => 1) { Priority = 1 });

			Assert.AreEqual(10, collection.Activate(null, null, new FauxInjectionContext(), null));
		}

		[TestMethod]
		public void RunTimeSortTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.RunTime)
			                     {
				                     Environment = ExportEnvironment.RunTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.DesignTime)
			                     {
				                     Environment =
					                     ExportEnvironment.DesignTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.UnitTest)
			                     {
				                     Environment =
					                     ExportEnvironment.UnitTest
			                     });

			Assert.AreEqual(ExportEnvironment.RunTime, collection.Activate(null, null, new FauxInjectionContext(), null));

			Assert.AreEqual(3, collection.ActivateAll<ExportEnvironment>(new FauxInjectionContext(), null).Count());
		}

		[TestMethod]
		public void DesignTimeSortTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.DesignTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.RunTime)
			                     {
				                     Environment = ExportEnvironment.RunTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.DesignTime)
			                     {
				                     Environment =
					                     ExportEnvironment.DesignTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.UnitTest)
			                     {
				                     Environment =
					                     ExportEnvironment.UnitTest
			                     });

			Assert.AreEqual(ExportEnvironment.DesignTime, collection.Activate(null, null, new FauxInjectionContext(), null));

			Assert.AreEqual(3, collection.ActivateAll<ExportEnvironment>(new FauxInjectionContext(), null).Count());
		}

		[TestMethod]
		public void UnitTestSortTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.UnitTest,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.RunTime)
			                     {
				                     Environment = ExportEnvironment.RunTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.DesignTime)
			                     {
				                     Environment =
					                     ExportEnvironment.DesignTime
			                     });
			collection.AddExport(new FauxExportStrategy(() => ExportEnvironment.UnitTest)
			                     {
				                     Environment =
					                     ExportEnvironment.UnitTest
			                     });

			Assert.AreEqual(ExportEnvironment.UnitTest, collection.Activate(null, null, new FauxInjectionContext(), null));

			Assert.AreEqual(3, collection.ActivateAll<ExportEnvironment>(new FauxInjectionContext(), null).Count());
		}

		[TestMethod]
		public void ActivateAll()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => 5) { Priority = 5 });
			collection.AddExport(new FauxExportStrategy(() => 10) { Priority = 10 });
			collection.AddExport(new FauxExportStrategy(() => 1) { Priority = 1 });

			List<int> exports = new List<int>(collection.ActivateAll<int>(new FauxInjectionContext(), null));

			Assert.AreEqual(3, exports.Count);
			Assert.AreEqual(10, exports[0]);
			Assert.AreEqual(5, exports[1]);
			Assert.AreEqual(1, exports[2]);
		}

		[TestMethod]
		public void FilterTest()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			collection.AddExport(new FauxExportStrategy(() => 5) { Priority = 5 });
			collection.AddExport(new FauxExportStrategy(() => 10) { Priority = 10 });
			collection.AddExport(new FauxExportStrategy(() => 1) { Priority = 1 });

			List<int> exports =
				new List<int>(collection.ActivateAll<int>(new FauxInjectionContext(),
					(context, strategy) => strategy.Priority % 2 == 1));

			Assert.AreEqual(2, exports.Count);
			Assert.AreEqual(5, exports[0]);
			Assert.AreEqual(1, exports[1]);
		}

		[TestMethod]
		public void EmptyActivate()
		{
			ExportStrategyCollection collection =
				new ExportStrategyCollection(new FauxInjectionScope(),
					ExportEnvironment.RunTime,
					DependencyInjectionContainer.CompareExportStrategies);

			object activated = collection.Activate(null, null, new FauxInjectionContext(), null);

			Assert.IsNull(activated);
		}
	}
}