﻿using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class FuncValueProviderTests
	{
		[TestMethod]
		public void ActivateTest()
		{
			FauxInjectionScope scope = new FauxInjectionScope();
			FauxInjectionContext context = new FauxInjectionContext { RequestingScope = scope };

			FuncWithContextValueProvider<IBasicService> provider =
				new FuncWithContextValueProvider<IBasicService>(x =>
				                                                {
					                                                Assert.IsTrue(ReferenceEquals(x, context));

					                                                return new BasicService();
				                                                });

			object activated = provider.Activate(scope, context, null);

			Assert.IsNotNull(activated);
			Assert.IsInstanceOfType(activated, typeof(BasicService));
		}
	}
}