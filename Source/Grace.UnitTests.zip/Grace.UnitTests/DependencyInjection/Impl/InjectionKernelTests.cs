﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Exceptions;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class InjectionKernelTests
	{
		private const string TEST_VALUE_STRING = "TestValue";
		private const string NEW_VALUE = "NewValue";

		#region Extra data test

		[TestMethod]
		public void ExtraDataTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			Assert.IsNull(injectionKernel.GetExtraData(TEST_VALUE_STRING));

			injectionKernel.SetExtraData(TEST_VALUE_STRING, NEW_VALUE);

			Assert.AreEqual(NEW_VALUE, injectionKernel.GetExtraData(TEST_VALUE_STRING));
		}

		#endregion

		#region Clone Tests

		[TestMethod]
		public void RootCloneExceptionTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			try
			{
				injectionKernel.Clone(null, null, null);

				throw new Exception("Should have thrown an exception when trying to clone root scope");
			}
			catch (RootScopeCloneException exp)
			{
			}
		}

		[TestMethod]
		public void CloneTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				new FauxInjectionScope(),
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy strategy = new FauxExportStrategy(() => new BasicService())
													{
														ExportNames = new[] { typeof(IBasicService).FullName }
													};

			injectionKernel.AddStrategy(strategy);

			IInjectionScope clone =
				injectionKernel.Clone(new FauxInjectionScope { ScopeName = "FauxParent" }, null, null);

			IExportStrategy exportStrategy =
				clone.GetStrategy(typeof(IBasicService), injectionKernel.CreateContext());

			Assert.IsTrue(ReferenceEquals(exportStrategy, strategy));
		}

		#endregion

		#region Add Remove Exports Tests

		[TestMethod]
		public void AddExportTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy strategy = new FauxExportStrategy(() => new BasicService())
													{
														ExportNames = new[] { typeof(IBasicService).FullName }
													};

			injectionKernel.AddStrategy(strategy);

			IExportStrategy exportStrategy =
				injectionKernel.GetStrategy(typeof(IBasicService), injectionKernel.CreateContext());

			Assert.IsTrue(ReferenceEquals(exportStrategy, strategy));
		}

		[TestMethod]
		public void RemoveExportTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy strategy = new FauxExportStrategy(() => new BasicService())
													{
														ExportNames = new[] { typeof(IBasicService).FullName }
													};

			injectionKernel.AddStrategy(strategy);

			IExportStrategy exportStrategy =
				injectionKernel.GetStrategy(typeof(IBasicService), injectionKernel.CreateContext());

			Assert.IsTrue(ReferenceEquals(exportStrategy, strategy));

			injectionKernel.RemoveStrategy(strategy);

			exportStrategy =
				injectionKernel.GetStrategy(typeof(IBasicService), injectionKernel.CreateContext());

			Assert.IsNull(exportStrategy);
		}

		#endregion

		#region Child Scope Tests

		[TestMethod]
		public void ChildScopeTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy strategy = new FauxExportStrategy(() => new BasicService())
													{
														ExportNames = new[] { typeof(IBasicService).FullName }
													};

			injectionKernel.AddStrategy(strategy);

			IInjectionScope child = injectionKernel.CreateChildScope();

			Assert.AreEqual(1, injectionKernel.ChildScopes().Count());

			IBasicService basicService = child.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
			Assert.IsInstanceOfType(basicService, typeof(BasicService));
		}

		[TestMethod]
		public void GetChildScopesTest()
		{
			InjectionKernelManager kernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(kernelManager,
				null,
				null,
				string.Empty,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy strategy = new FauxExportStrategy(() => new BasicService())
													{
														ExportNames = new[] { typeof(IBasicService).FullName }
													};

			injectionKernel.AddStrategy(strategy);

			IInjectionScope child = injectionKernel.CreateChildScope();
			IInjectionScope child2 = injectionKernel.CreateChildScope();
			IInjectionScope child3 = injectionKernel.CreateChildScope();

			Assert.AreEqual(3, injectionKernel.ChildScopes().Count());
		}

		#endregion

		#region Basic Tests

		[TestMethod]
		public void BasicFuncExportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc =>
				{
					ioc.ExportFunc((scope, context) => new BasicService()).As<IBasicService>();
					ioc.ExportFunc((scope, context) => new ImportPropertyService())
						.As<IImportPropertyService>()
						.ImportProperty(x => x.BasicService);
				});

			IImportPropertyService importPropertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		[TestMethod]
		public void BasicInstanceExportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc =>
				{
					ioc.Export<BasicService>().As<IBasicService>();
					ioc.Export<ConstructorImportService>().As<IConstructorImportService>();
				});

			IConstructorImportService importPropertyService = injectionKernel.Locate<IConstructorImportService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		#endregion

		#region Dispose Tests

		[TestMethod]
		public void DisposeInjectionKernel()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc => ioc.Export<DisposableService>().As<IDisposableService>());

			IDisposableService disposableService = injectionKernel.Locate<IDisposableService>();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			injectionKernel.Dispose();

			Assert.IsTrue(eventFired);

			eventFired = false;

			injectionKernel.Dispose();

			Assert.IsFalse(eventFired);
		}

		[TestMethod]
		public void DisposeInjectionKernelWithParent()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc => ioc.Export<DisposableService>().As<IDisposableService>());

			IInjectionScope newInjectionScope = injectionKernel.CreateChildScope();

			IEnumerable<IInjectionScope> children = injectionKernel.ChildScopes();

			Assert.AreEqual(1, children.Count());

			IDisposableService disposableService = newInjectionScope.Locate<IDisposableService>();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			newInjectionScope.Dispose();

			Assert.IsTrue(eventFired);

			children = injectionKernel.ChildScopes();

			Assert.AreEqual(0, children.Count());
		}

		[TestMethod]
		public void DisposeInjectionKernelWithChildren()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc => ioc.Export<DisposableService>().As<IDisposableService>());

			IInjectionScope newInjectionScope = injectionKernel.CreateChildScope();

			IEnumerable<IInjectionScope> children = injectionKernel.ChildScopes();

			Assert.AreEqual(1, children.Count());

			IDisposableService disposableService = newInjectionScope.Locate<IDisposableService>();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			injectionKernel.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void DisposeInjectionKernelAndLifeCycle()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc => ioc.Export<DisposableService>().As<IDisposableService>().AndSingleton());

			IDisposableService disposableService = injectionKernel.Locate<IDisposableService>();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			injectionKernel.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void DisposalScopeProvider()
		{
			DisposalScope disposalScope = new DisposalScope();

			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());

			InjectionKernel injectionKernel =
				new InjectionKernel(manager,
					null,
					new FauxDisposalScopeProvider(() => disposalScope),
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposableService>().As<IDisposableService>());

			IDisposableService disposableService = injectionKernel.Locate<IDisposableService>();

			bool disposed = false;

			disposableService.Disposing += (sender, args) => disposed = true;

			disposalScope.Dispose();

			Assert.IsTrue(disposed);
		}

		#endregion

		#region Locate Tests

		[TestMethod]
		public void LocateByNameInParent()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export(typeof(BasicService)).AsName("BasicService"));

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			BasicService basicService = (BasicService)childScope.Locate("BasicService");

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void LocateByNameWithContextInParent()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export(typeof(BasicService)).AsName("BasicService"));

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			BasicService basicService = (BasicService)childScope.Locate("BasicService", childScope.CreateContext());

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void LocateAllTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().AsName("ISimpleObject");
												  c.Export<SimpleObjectB>().AsName("ISimpleObject");
												  c.Export<SimpleObjectC>().AsName("ISimpleObject");
												  c.Export<SimpleObjectD>().AsName("ISimpleObject");
												  c.Export<SimpleObjectE>().AsName("ISimpleObject");
											  });

			IEnumerable<object> simpleObjects = injectionKernel.LocateAll("ISimpleObject");

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		[TestMethod]
		public void LocateAllWithFilterTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().AsName("ISimpleObject");
												  c.Export<SimpleObjectB>().AsName("ISimpleObject");
												  c.Export<SimpleObjectC>().AsName("ISimpleObject");
												  c.Export<SimpleObjectD>().AsName("ISimpleObject");
												  c.Export<SimpleObjectE>().AsName("ISimpleObject");
											  });

			IEnumerable<object> simpleObjects =
				injectionKernel.LocateAll("ISimpleObject",
					consider:
						(context, strategy) =>
							strategy.ActivationName.EndsWith("A") || strategy.ActivationName.EndsWith("C"));

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(2, simpleObjects.Count());
		}

		#endregion

		#region Locate Generic Tests

		[TestMethod]
		public void LocateAllGenericTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IEnumerable<ISimpleObject> simpleObjects = injectionKernel.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		[TestMethod]
		public void LocateAllGenericFromParentTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			IEnumerable<ISimpleObject> simpleObjects = childScope.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		[TestMethod]
		public void LocateWithKeyTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>().WithKey(5);
												  c.Export<SimpleObjectB>().As<ISimpleObject>().WithKey(10);
												  c.Export<SimpleObjectC>().As<ISimpleObject>().WithKey(20);
											  });

			Assert.IsInstanceOfType(injectionKernel.LocateByKey<ISimpleObject, int>(5), typeof(SimpleObjectA));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey<ISimpleObject, int>(10), typeof(SimpleObjectB));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey<ISimpleObject, int>(20), typeof(SimpleObjectC));
		}

		[TestMethod]
		public void LocateObservableCollection()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
												  c.Export<ImportReadOnlyCollectionService>();
											  });

			ObservableCollection<ISimpleObject> observableCollection =
				injectionKernel.Locate<ObservableCollection<ISimpleObject>>();

			Assert.IsNotNull(observableCollection);
			Assert.AreEqual(5, observableCollection.Count);
		}

		[TestMethod]
		public void LocateAllGenericFromParentCombinedTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
											  });

			IInjectionScope childScope = injectionKernel.CreateChildScope(
				c =>
				{
					c.Export<SimpleObjectC>().As<ISimpleObject>();
					c.Export<SimpleObjectD>().As<ISimpleObject>();
					c.Export<SimpleObjectE>().As<ISimpleObject>();
				});

			IEnumerable<ISimpleObject> simpleObjects = childScope.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		[TestMethod]
		public void LocateAllGenericWithFilterTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IEnumerable<object> simpleObjects =
				injectionKernel.LocateAll<ISimpleObject>(consider: (context, strategy) => strategy.ActivationName.EndsWith("A") ||
																												  strategy.ActivationName.EndsWith("C"));

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(2, simpleObjects.Count());
		}

		[TestMethod]
		public void ConstrainedTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<BasicService>().As<IBasicService>();
												  c.Export(typeof(GenericService<>)).As(typeof(IGenericService<>));
												  c.Export(typeof(ConstrainedService<>)).As(typeof(IGenericService<>)).WithPriority(10);
											  });

			IGenericService<int> genericService = injectionKernel.Locate<IGenericService<int>>();

			Assert.IsNotNull(genericService);
			Assert.IsInstanceOfType(genericService, typeof(GenericService<int>));

			IGenericService<IBasicService> basicGenericService = injectionKernel.Locate<IGenericService<IBasicService>>();

			Assert.IsNotNull(basicGenericService);
			Assert.IsInstanceOfType(basicGenericService, typeof(ConstrainedService<IBasicService>));
		}

		[TestMethod]
		public void MultipleImportConstructor()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);
			injectionKernel.Configure(c =>
											  {
												  c.Export<BasicService>().As<IBasicService>();
												  c.Export<ConstructorImportService>().As<IConstructorImportService>();
												  c.Export<MultipleConstructorImport>();
											  });

			MultipleConstructorImport import = injectionKernel.Locate<MultipleConstructorImport>();

			Assert.IsNotNull(import);
			Assert.IsNotNull(import.BasicService);
			Assert.IsNotNull(import.ConstructorImportService);
		}

		[TestMethod]
		public void ImportIEnumerable()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
												  c.Export<ImportIEnumerableService>();
											  });

			ImportIEnumerableService service = injectionKernel.Locate<ImportIEnumerableService>();

			Assert.IsNotNull(service);
			Assert.AreEqual(5, service.Count);
		}

		[TestMethod]
		public void ImportIReadOnlyCollection()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
												  c.Export<ImportReadOnlyCollectionService>();
											  });

			ImportReadOnlyCollectionService service = injectionKernel.Locate<ImportReadOnlyCollectionService>();

			Assert.IsNotNull(service);
		}

		[TestMethod]
		public void ImportObservableCollection()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
												  c.Export<ImportObservableCollectionService>();
											  });

			ImportObservableCollectionService service =
				injectionKernel.Locate<ImportObservableCollectionService>();

			Assert.IsNotNull(service);
			Assert.AreEqual(5, service.Count);
		}

		[TestMethod]
		public void ImportOwnedTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<DisposableService>().As<IDisposableService>();
												  c.Export<ImportOwnedService>();
											  });
		}

		[TestMethod]
		public void ImportLazyTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());

			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<BasicService>().As<IBasicService>();
												  c.Export<LazyImportService>();
											  });

			LazyImportService importService = injectionKernel.Locate<LazyImportService>();

			Assert.IsNotNull(importService);

			IBasicService basicService = importService.BasicService;

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void ImportDisposalScope()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposalScopeInjectionService>());

			DisposalScopeInjectionService service = injectionKernel.Locate<DisposalScopeInjectionService>();

			Assert.IsNotNull(service);
			Assert.IsNotNull(service.DisposalScope);
			Assert.IsTrue(ReferenceEquals(service.DisposalScope, injectionKernel));
		}

		[TestMethod]
		public void ImportFunc()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<BasicService>().As<IBasicService>();
												  c.Export<FuncImportService>().As<IFuncImportService>();
											  });

			IFuncImportService funcImportService = injectionKernel.Locate<IFuncImportService>();

			Assert.IsNotNull(funcImportService);

			IBasicService basicService = funcImportService.GetBasicService();

			Assert.IsNotNull(basicService);
		}

		#endregion

		#region Get Strategies Tests

		[TestMethod]
		public void GetAllStrategiesByType()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IEnumerable<IExportStrategy> strategies =
				injectionKernel.GetStrategies(typeof(ISimpleObject), injectionKernel.CreateContext());

			Assert.IsNotNull(strategies);
			Assert.AreEqual(5, strategies.Count());
		}

		[TestMethod]
		public void GetAllStrategiesByName()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().AsName("ISimpleObject");
												  c.Export<SimpleObjectB>().AsName("ISimpleObject");
												  c.Export<SimpleObjectC>().AsName("ISimpleObject");
												  c.Export<SimpleObjectD>().AsName("ISimpleObject");
												  c.Export<SimpleObjectE>().AsName("ISimpleObject");
											  });

			IEnumerable<IExportStrategy> strategies =
				injectionKernel.GetStrategies("ISimpleObject", injectionKernel.CreateContext());

			Assert.IsNotNull(strategies);
			Assert.AreEqual(5, strategies.Count());
		}

		[TestMethod]
		public void GetAllStrategiesByTypeFiltered()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IEnumerable<IExportStrategy> strategies =
				injectionKernel.GetStrategies(typeof(ISimpleObject),
					injectionKernel.CreateContext(),
					(context, strategy) =>
						strategy.ActivationName.EndsWith("A") || strategy.ActivationName.EndsWith("C"));

			Assert.IsNotNull(strategies);
			Assert.AreEqual(2, strategies.Count());
		}

		[TestMethod]
		public void GetAllStrategiesByNameFiltered()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().AsName("ISimpleObject");
												  c.Export<SimpleObjectB>().AsName("ISimpleObject");
												  c.Export<SimpleObjectC>().AsName("ISimpleObject");
												  c.Export<SimpleObjectD>().AsName("ISimpleObject");
												  c.Export<SimpleObjectE>().AsName("ISimpleObject");
											  });

			IEnumerable<IExportStrategy> strategies =
				injectionKernel.GetStrategies("ISimpleObject",
					injectionKernel.CreateContext(),
					(context, strategy) =>
						strategy.ActivationName.EndsWith("A") || strategy.ActivationName.EndsWith("C"));

			Assert.IsNotNull(strategies);
			Assert.AreEqual(2, strategies.Count());
		}

		#endregion

		#region Misc Config Tests

		[TestMethod]
		public void ConfigurationModuleTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(new SimpleModule());

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void AddExportStrategy()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			FauxExportStrategy basicExport = new FauxExportStrategy(() => new BasicService());

			basicExport.ExportNames = new List<string> { typeof(IBasicService).FullName };

			injectionKernel.Configure(c => c.AddExportStrategy(basicExport));

			IBasicService basicService =
				injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		#endregion

		#region Special Types

		[TestMethod]
		public void OwnedResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposableService>().As<IDisposableService>());

			Owned<IDisposableService> owned = injectionKernel.Locate<Owned<IDisposableService>>();

			Assert.IsNotNull(owned);
			Assert.IsNotNull(owned.Value);

			bool eventCalled = false;

			owned.Value.Disposing += (sender, args) => eventCalled = true;

			owned.Dispose();

			Assert.IsTrue(eventCalled);
		}

		[TestMethod]
		public void FuncResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			Func<IBasicService> basicServiceFunc = injectionKernel.Locate<Func<IBasicService>>();

			Assert.IsNotNull(basicServiceFunc);

			IBasicService basicService = basicServiceFunc();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void GenericFuncImport()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<MultiplePropertyImportService>().AutoWireProperties(true));

			Func<IImportConstructorService, IImportMethodService, IImportPropertyService, MultiplePropertyImportService> func =
				injectionKernel
					.Locate
					<Func<IImportConstructorService, IImportMethodService, IImportPropertyService, MultiplePropertyImportService>>();

			MultiplePropertyImportService importService =
				func(new ImportConstructorService(new BasicService()), new ImportMethodService(), new ImportPropertyService());

			Assert.IsNotNull(importService);
			Assert.IsNotNull(importService.ConstructorService);
			Assert.IsNotNull(importService.MethodService);
			Assert.IsNotNull(importService.PropertyService);
		}

		[TestMethod]
		public void OwnedFuncResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposableService>().As<IDisposableService>());

			Owned<Func<IDisposableService>> ownedFunc = injectionKernel.Locate<Owned<Func<IDisposableService>>>();

			Assert.IsNotNull(ownedFunc);
			Assert.IsNotNull(ownedFunc.Value);

			int count = 0;

			IDisposableService service1 = ownedFunc.Value();

			service1.Disposing += (sender, args) => count++;

			IDisposableService service2 = ownedFunc.Value();

			service2.Disposing += (sender, args) => count++;

			IDisposableService service3 = ownedFunc.Value();

			service3.Disposing += (sender, args) => count++;

			ownedFunc.Dispose();

			Assert.AreEqual(3, count);
		}

		[TestMethod]
		public void FuncOwnedResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposableService>().As<IDisposableService>());

			Func<Owned<IDisposableService>> ownedFunc = injectionKernel.Locate<Func<Owned<IDisposableService>>>();

			Assert.IsNotNull(ownedFunc);

			Owned<IDisposableService> owned = ownedFunc();

			Assert.IsNotNull(owned);
			Assert.IsNotNull(owned.Value);

			bool eventCalled = false;

			owned.Value.Disposing += (sender, args) => eventCalled = true;

			owned.Dispose();

			Assert.IsTrue(eventCalled);

			owned = ownedFunc();

			Assert.IsNotNull(owned);
			Assert.IsNotNull(owned.Value);

			eventCalled = false;

			owned.Value.Disposing += (sender, args) => eventCalled = true;

			owned.Dispose();

			Assert.IsTrue(eventCalled);
		}

		[TestMethod]
		public void LazyResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			Lazy<IBasicService> lazyBasic = injectionKernel.Locate<Lazy<IBasicService>>();

			Assert.IsNotNull(lazyBasic);
			Assert.IsFalse(lazyBasic.IsValueCreated);
			Assert.IsNotNull(lazyBasic.Value);
		}

		[TestMethod]
		public void ReadOnlyCollectionResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			ReadOnlyCollection<ISimpleObject> readOnlyCollection =
				injectionKernel.Locate<ReadOnlyCollection<ISimpleObject>>();

			Assert.IsNotNull(readOnlyCollection);
			Assert.AreEqual(5, readOnlyCollection.Count);
		}

		[TestMethod]
		public void IReadOnlyCollectionResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IReadOnlyCollection<ISimpleObject> readOnlyCollection =
				injectionKernel.Locate<IReadOnlyCollection<ISimpleObject>>();

			Assert.IsNotNull(readOnlyCollection);
			Assert.AreEqual(5, readOnlyCollection.Count);
		}

		[TestMethod]
		public void IReadOnlyListResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			IReadOnlyList<ISimpleObject> readOnlyCollection =
				injectionKernel.Locate<IReadOnlyList<ISimpleObject>>();

			Assert.IsNotNull(readOnlyCollection);
			Assert.AreEqual(5, readOnlyCollection.Count);
		}

		[TestMethod]
		public void ArrayResolve()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
											  {
												  c.Export<SimpleObjectA>().As<ISimpleObject>();
												  c.Export<SimpleObjectB>().As<ISimpleObject>();
												  c.Export<SimpleObjectC>().As<ISimpleObject>();
												  c.Export<SimpleObjectD>().As<ISimpleObject>();
												  c.Export<SimpleObjectE>().As<ISimpleObject>();
											  });

			ISimpleObject[] simpleObjects = injectionKernel.Locate<ISimpleObject[]>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Length);
		}

		[TestMethod]
		public void DisposalScopeImportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<DisposalScopeInjectionService>());

			DisposalScopeInjectionService disposableService = injectionKernel.Locate<DisposalScopeInjectionService>();

			Assert.IsNotNull(disposableService);
			Assert.IsNotNull(disposableService.DisposalScope);
			Assert.AreSame(injectionKernel, disposableService.DisposalScope);
		}

		[TestMethod]
		public void InjectionContextImportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<InjectionScopeImportService>());

			InjectionScopeImportService importService = injectionKernel.Locate<InjectionScopeImportService>();

			Assert.IsNotNull(importService);
			Assert.IsNotNull(importService.InjectionScope);
			Assert.AreSame(injectionKernel, importService.InjectionScope);
		}


		[TestMethod]
		public void TransientInjectionContextImportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<InjectionScopeImportService>());

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			InjectionScopeImportService importService = childScope.Locate<InjectionScopeImportService>();

			Assert.IsNotNull(importService);
			Assert.IsNotNull(importService.InjectionScope);
			Assert.AreSame(childScope, importService.InjectionScope);
		}

		[TestMethod]
		public void NonTransientInjectionContextImportTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<InjectionScopeImportService>().AndSingleton());

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			InjectionScopeImportService importService = childScope.Locate<InjectionScopeImportService>();

			Assert.IsNotNull(importService);
			Assert.IsNotNull(importService.InjectionScope);
			Assert.AreSame(injectionKernel, importService.InjectionScope);
		}

		[TestMethod]
		public void ImportFuncType()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<FuncTypeImportService>();
			                          });

			FuncTypeImportService importService = injectionKernel.Locate<FuncTypeImportService>();

			Assert.IsNotNull(importService);
			Assert.IsInstanceOfType(importService.Create(typeof(IBasicService)), typeof(BasicService));
		}

		[TestMethod]
		public void CreateFuncType()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			{
				c.Export<BasicService>().As<IBasicService>();
			});

			Func<Type, object> importService = injectionKernel.Locate<Func<Type, object>>();

			Assert.IsNotNull(importService);
			Assert.IsInstanceOfType(importService(typeof(IBasicService)),typeof(BasicService));
		}

		#endregion

		#region Register Assembly

		[TestMethod]
		public void AssemblyExportInterfaceTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			Assembly assembly = GetType().GetTypeInfo().Assembly;

			injectionKernel.Configure(c => c.ExportAssembly(assembly).ExportInterface(typeof(ISimpleObject)));

			IEnumerable<ISimpleObject> simpleObjects =
				injectionKernel.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		#endregion
	}
}