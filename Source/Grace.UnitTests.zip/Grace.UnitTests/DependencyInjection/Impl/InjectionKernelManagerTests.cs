﻿using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class InjectionKernelManagerTests
	{
		[TestMethod]
		public void NamedCloneTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel kernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			manager.SetRootScope(kernel);

			manager.Configure("TestKernel", c => c.Export<BasicService>().As<IBasicService>());

			IInjectionScope injectionScope = manager.CreateNewKernel(kernel, "TestKernel", null, null, null);

			IBasicService basicService = injectionScope.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void NamedCloneWithRegistrationTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel kernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			manager.SetRootScope(kernel);

			manager.Configure("TestKernel", c => c.Export<BasicService>().As<IBasicService>());

			IInjectionScope injectionScope =
				manager.CreateNewKernel(kernel,
					"TestKernel",
					c => c.Export<ImportConstructorService>().As<IImportConstructorService>(),
					null,
					null);

			IImportConstructorService importService = injectionScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(importService);
		}

		[TestMethod]
		public void NonNamedCloneTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel kernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			kernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			IInjectionScope injectionScope = manager.CreateNewKernel(kernel, null, null, null, null);

			IBasicService basicService = injectionScope.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void NonNamedCloneWithRegistrationTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel kernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			kernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			IInjectionScope injectionScope =
				manager.CreateNewKernel(kernel,
					null,
					c => c.Export<ImportConstructorService>().As<IImportConstructorService>(),
					null,
					null);

			IImportConstructorService importService = injectionScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(importService);
		}
	}
}