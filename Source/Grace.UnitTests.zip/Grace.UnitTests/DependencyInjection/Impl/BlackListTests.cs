﻿using System.Collections;
using System.Collections.Generic;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class BlackListTests
	{
		[TestMethod]
		public void BasicClassTest()
		{
			BlackList blackList = new BlackList { "Hello", "World" };

			List<string> newList = new List<string>(blackList);

			Assert.AreEqual(2, newList.Count);
			Assert.AreEqual("Hello", newList[0]);
			Assert.AreEqual("World", newList[1]);
		}

		[TestMethod]
		public void EnumerableTest()
		{
			BlackList blackList = new BlackList { "Hello", "World" };

			List<string> newList = new List<string>();

			foreach (object o in (IEnumerable)blackList)
			{
				newList.Add((string)o);
			}

			Assert.AreEqual(2, newList.Count);
			Assert.AreEqual("Hello", newList[0]);
			Assert.AreEqual("World", newList[1]);
		}

		[TestMethod]
		public void IsBlackedListedTest()
		{
			BlackList blackList = new BlackList { "Hello", "World" };

			Assert.IsTrue(blackList.IsExportStrategyBlackedOut(new FauxExportStrategy(() => new object())
			                                                   {
				                                                   ActivationName = "Hello",
			                                                   }));

			Assert.IsTrue(blackList.IsExportStrategyBlackedOut(new FauxExportStrategy(() => new object())
			                                                   {
				                                                   ActivationName = "World"
			                                                   }));

			Assert.IsFalse(blackList.IsExportStrategyBlackedOut(new FauxExportStrategy(() => new object())
			                                                    {
				                                                    ActivationName = "GoodBye"
			                                                    }));
		}
	}
}