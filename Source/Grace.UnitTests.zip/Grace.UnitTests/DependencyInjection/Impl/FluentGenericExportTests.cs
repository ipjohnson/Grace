﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Conditions;
using Grace.DependencyInjection.Impl;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class FluentGenericExportTests
	{
		[TestMethod]
		public void RegisterWithoutAs()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>());

			BasicService basicService = injectionKernel.Locate<BasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void RegisterAsType()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void RegisterAsName()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>());

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void RegisterAsTypeAndName()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().AsName("IBasicService").As<IBasicService>());

			IBasicService basicService = injectionKernel.Locate("IBasicService") as IBasicService;

			Assert.IsNotNull(basicService);

			basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void RegisterAsTypeAndNameAndSingleton()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				c => c.Export<BasicService>().AsName("IBasicService").As<IBasicService>().AndSingleton());

			IBasicService basicService = injectionKernel.Locate("IBasicService") as IBasicService;

			Assert.IsNotNull(basicService);

			IBasicService basicService2 = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService2);

			Assert.IsTrue(ReferenceEquals(basicService, basicService2));
		}

		[TestMethod]
		public void RegisterConstructorImport()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportConstructorService>().As<IImportConstructorService>();
			                          });

			IImportConstructorService constructorService = injectionKernel.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void RegisterImportProperty()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(o => o.BasicService);
			                          });

			IImportPropertyService importPropertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		[TestMethod]
		public void RegisterImportPropertyWithFilter()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.ExportAssembly(GetType().Assembly).ExportInterface(typeof(ISimpleObject));
				                          c.Export<ImportPropertySimpleObject>()
					                          .ImportProperty(x => x.SimpleObject, consider: ExportsThat.EndWith("C"));
			                          });

			ImportPropertySimpleObject import = injectionKernel.Locate<ImportPropertySimpleObject>();

			Assert.IsNotNull(import);
			Assert.IsNotNull(import.SimpleObject);
			Assert.IsInstanceOfType(import.SimpleObject, typeof(SimpleObjectC));
		}

		[TestMethod]
		public void RegisterImportPropertyWithFuncVale()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<ImportPropertyService>()
				.As<IImportPropertyService>()
				.ImportProperty(o => o.BasicService, x => new BasicService()));

			IImportPropertyService importPropertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		[TestMethod]
		public void RegisterImportMethodWithDefaults()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportMethodWithArgs>().
					                          ImportMethod(x => x.ImportMethod(null, null, 0),
						                          new
						                          {
							                          stringParam = "Hello",
							                          intParam = new Func<int>(() => 7)
						                          });
			                          });

			ImportMethodWithArgs import = injectionKernel.Locate<ImportMethodWithArgs>();

			Assert.IsNotNull(import);
			Assert.IsNotNull(import.BasicService);
			Assert.IsNotNull(import.StringParam);
			Assert.AreEqual("Hello", import.StringParam);
			Assert.AreEqual(7, import.IntParam);
		}

		[TestMethod]
		public void RegisterImportMethodWithDefaultsDictionary()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportMethodWithArgs>().
					                          ImportMethod(x => x.ImportMethod(null, null, 0),
						                          new Dictionary<string, object>
						                          {
							                          { "stringParam", "Hello" },
							                          { "intParam", new Func<int>(() => 7) }
						                          });
			                          });

			ImportMethodWithArgs import = injectionKernel.Locate<ImportMethodWithArgs>();

			Assert.IsNotNull(import);
			Assert.IsNotNull(import.BasicService);
			Assert.IsNotNull(import.StringParam);
			Assert.AreEqual("Hello", import.StringParam);
			Assert.AreEqual(7, import.IntParam);
		}

		[TestMethod]
		public void RegisterImportPropertyWithExportProvider()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<ImportPropertyService>()
				.As<IImportPropertyService>()
				.ImportProperty(o => o.BasicService,
					new FuncWithContextValueProvider<BasicService>(
						con => new BasicService())));

			IImportPropertyService importPropertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		[TestMethod]
		public void AutoWireAllProperties()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(x => x.BasicService);
				                          c.Export<ImportMethodService>()
					                          .As<IImportMethodService>()
					                          .ImportMethod(o => o.ImportMethod(null));
				                          c.Export<MultiplePropertyImportService>()
					                          .As<IMultiplePropertyImportService>()
					                          .AutoWireProperties();
			                          });

			IMultiplePropertyImportService multiplePropertyImportService =
				injectionKernel.Locate<IMultiplePropertyImportService>();

			Assert.IsNotNull(multiplePropertyImportService);
			Assert.IsNotNull(multiplePropertyImportService.ConstructorService);
			Assert.IsNotNull(multiplePropertyImportService.MethodService);
			Assert.IsNotNull(multiplePropertyImportService.PropertyService);
		}

		[TestMethod]
		public void ActivateMethods()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());

			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<ActivateService>()
				.As<IActiveService>()
				.ActivationMethod(o => o.SimpleActivate())
				.ActivationMethod(o => o.InjectionContextActivate(null)));

			IActiveService activeService = injectionKernel.Locate<IActiveService>();

			Assert.IsNotNull(activeService);
			Assert.IsTrue(activeService.SimpleActivateCalled);
			Assert.IsTrue(activeService.InjectionContextActivateCalled);
		}

		[TestMethod]
		public void RegisterImportMethod()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportMethodService>()
					                          .As<IImportMethodService>()
					                          .ImportMethod(o => o.ImportMethod(null));
			                          });

			IImportMethodService importMethodService = injectionKernel.Locate<IImportMethodService>();

			Assert.IsNotNull(importMethodService);
			Assert.IsNotNull(importMethodService.BasicService);
		}

		[TestMethod]
		public void RegisterMultipleImportType()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(o => o.BasicService);
				                          c.Export<ImportAllTypes>()
					                          .ImportProperty(o => o.PropertyService)
					                          .ImportMethod(o => o.ImportMethod(null));
			                          });

			ImportAllTypes importAllTypes = injectionKernel.Locate<ImportAllTypes>();

			Assert.IsNotNull(importAllTypes);
			Assert.IsNotNull(importAllTypes.PropertyService);
			Assert.IsNotNull(importAllTypes.ImportConstructorService);
		}

		[TestMethod]
		public void RegisterArrayImport()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectB>().As<ISimpleObject>();
				                          c.Export<SimpleObjectC>().As<ISimpleObject>();
				                          c.Export<SimpleObjectD>().As<ISimpleObject>();
				                          c.Export<SimpleObjectE>().As<ISimpleObject>();
				                          c.Export<ImportArrayService>().As<IImportArrayService>();
			                          });

			IImportArrayService arrayService = injectionKernel.Locate<IImportArrayService>();

			Assert.IsNotNull(arrayService);
		}

		[TestMethod]
		public void RegisterInstancePerScope()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>().AndSingletonPerScope());

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);

			Assert.IsTrue(ReferenceEquals(basicService, injectionKernel.Locate<IBasicService>()));

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			IBasicService secondService = childScope.Locate<IBasicService>();

			Assert.IsNotNull(secondService);
			Assert.IsFalse(ReferenceEquals(basicService, secondService));
			Assert.IsTrue(ReferenceEquals(secondService, childScope.Locate<IBasicService>()));
		}

		[TestMethod]
		public void RegisterWeakSingleton()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>().AndWeakSingleton());

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);

			Assert.IsTrue(ReferenceEquals(basicService, injectionKernel.Locate<IBasicService>()));

			IInjectionScope childScope = injectionKernel.CreateChildScope();

			IBasicService secondService = childScope.Locate<IBasicService>();

			Assert.IsNotNull(secondService);
			Assert.IsTrue(ReferenceEquals(basicService, secondService));
			Assert.IsTrue(ReferenceEquals(secondService, childScope.Locate<IBasicService>()));
		}

		[TestMethod]
		public void EnrichWithDelegate()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export<BasicService>().As<IBasicService>().
				EnrichWith(
					(scope, context, enrichObject) =>
						new BasicServiceWrapper(enrichObject as IBasicService)));

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
			Assert.IsInstanceOfType(basicService, typeof(BasicServiceWrapper));

			BasicServiceWrapper wrapper = basicService as BasicServiceWrapper;

			Assert.IsNotNull(wrapper.BasicService);
			Assert.IsInstanceOfType(wrapper.BasicService, typeof(BasicService));
		}

		[TestMethod]
		public void PriorityTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<FauxBasicService>().As<IBasicService>().WithPriority(1);
			                          });

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
			Assert.IsInstanceOfType(basicService, typeof(FauxBasicService));
		}

		[TestMethod]
		public void UsingLifeCycleContainerTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				c => c.Export<BasicService>().As<IBasicService>().UsingLifeCycleContainer(new SingletonContainer()));

			IBasicService basicService = injectionKernel.Locate<IBasicService>();

			Assert.IsNotNull(basicService);

			Assert.IsTrue(ReferenceEquals(basicService, injectionKernel.Locate<IBasicService>()));
		}

		[TestMethod]
		public void AndConditionTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(o => o.BasicService);

				                          c.Export<ImportMethodService>()
					                          .As<IImportMethodService>()
					                          .ImportMethod(o => o.ImportMethod(null));

				                          c.Export<BasicService>()
					                          .As<IBasicService>()
					                          .AndCondition(
						                          new WhenCondition(
							                          (x, y, z) => y.TargetInfo.InjectionType == typeof(ImportPropertyService)));

				                          c.Export<FauxBasicService>()
					                          .As<IBasicService>()
					                          .AndCondition(
						                          new WhenCondition(
							                          (x, y, z) => y.TargetInfo.InjectionType == typeof(ImportMethodService)));
			                          });

			IImportPropertyService propertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
			Assert.IsInstanceOfType(propertyService.BasicService, typeof(BasicService));

			IImportMethodService methodService = injectionKernel.Locate<IImportMethodService>();

			Assert.IsNotNull(methodService);
			Assert.IsNotNull(methodService.BasicService);
			Assert.IsInstanceOfType(methodService.BasicService, typeof(FauxBasicService));
		}

		[TestMethod]
		public void WhenConditionTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(o => o.BasicService);

				                          c.Export<ImportMethodService>()
					                          .As<IImportMethodService>()
					                          .ImportMethod(o => o.ImportMethod(null));

				                          c.Export<BasicService>()
					                          .As<IBasicService>()
					                          .When((x, y, z) => y.TargetInfo.InjectionType == typeof(ImportPropertyService));

				                          c.Export<FauxBasicService>()
					                          .As<IBasicService>()
					                          .When((x, y, z) => y.TargetInfo.InjectionType == typeof(ImportMethodService));
			                          });

			IImportPropertyService propertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
			Assert.IsInstanceOfType(propertyService.BasicService, typeof(BasicService));

			IImportMethodService methodService = injectionKernel.Locate<IImportMethodService>();

			Assert.IsNotNull(methodService);
			Assert.IsNotNull(methodService.BasicService);
			Assert.IsInstanceOfType(methodService.BasicService, typeof(FauxBasicService));
		}

		[TestMethod]
		public void UnlessConditionTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<ImportPropertyService>()
					                          .As<IImportPropertyService>()
					                          .ImportProperty(o => o.BasicService);

				                          c.Export<ImportMethodService>()
					                          .As<IImportMethodService>()
					                          .ImportMethod(o => o.ImportMethod(null));

				                          c.Export<BasicService>()
					                          .As<IBasicService>()
					                          .Unless((x, y, z) => y.TargetInfo.InjectionType == typeof(ImportPropertyService));

				                          c.Export<FauxBasicService>()
					                          .As<IBasicService>()
					                          .Unless((x, y, z) => y.TargetInfo.InjectionType == typeof(ImportMethodService));
			                          });

			IImportPropertyService propertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
			Assert.IsInstanceOfType(propertyService.BasicService, typeof(FauxBasicService));

			IImportMethodService methodService = injectionKernel.Locate<IImportMethodService>();

			Assert.IsNotNull(methodService);
			Assert.IsNotNull(methodService.BasicService);
			Assert.IsInstanceOfType(methodService.BasicService, typeof(BasicService));
		}

		[TestMethod]
		public void WhenClassHas()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>().WhenClassHas<SomeTestAttribute>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>().WhenClassHas<SomeTestAttribute>();
				                          c.Export<AttributedClassMultipleImport>();
				                          c.Export<ImportIEnumerableService>();
			                          });

			ImportIEnumerableService iEnumerableService = injectionKernel.Locate<ImportIEnumerableService>();

			Assert.IsNotNull(iEnumerableService);
			Assert.AreEqual(3, iEnumerableService.Count);

			AttributedClassMultipleImport multipleImport = injectionKernel.Locate<AttributedClassMultipleImport>();

			Assert.IsNotNull(multipleImport);
			Assert.AreEqual(5, multipleImport.SimpleObjects.Count());
		}

		[TestMethod]
		public void WhenMemberHas()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>().WhenMemberHas<SomeTestAttribute>();
				                          c.Export<SimpleObjectA>().As<ISimpleObject>().WhenMemberHas<SomeTestAttribute>();
				                          c.Export<AttributedMethodMultipleImport>().ImportMethod(x => x.ImportMethod(null));
				                          c.Export<AttributedPropertyMultipleImport>().ImportProperty(x => x.SimpleObjects);
				                          c.Export<ImportIEnumerableService>();
			                          });

			ImportIEnumerableService iEnumerableService = injectionKernel.Locate<ImportIEnumerableService>();

			Assert.IsNotNull(iEnumerableService);
			Assert.AreEqual(3, iEnumerableService.Count);

			AttributedMethodMultipleImport multipleImport = injectionKernel.Locate<AttributedMethodMultipleImport>();

			Assert.IsNotNull(multipleImport);
			Assert.AreEqual(5, multipleImport.Count);

			AttributedPropertyMultipleImport propertyMultipleImport = injectionKernel.Locate<AttributedPropertyMultipleImport>();

			Assert.IsNotNull(propertyMultipleImport);
			Assert.AreEqual(5, propertyMultipleImport.SimpleObjects.Length);
		}

		[TestMethod]
		public void LocateWithKey()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>().AsName("ISimpleObject").WithKey(1);
				                          c.Export<SimpleObjectB>().AsName("ISimpleObject").WithKey(2);
				                          c.Export<SimpleObjectC>().AsName("ISimpleObject").WithKey(3);
				                          c.Export<SimpleObjectD>().AsName("ISimpleObject").WithKey(4);
				                          c.Export<SimpleObjectE>().AsName("ISimpleObject").WithKey(5);
			                          });

			Assert.IsInstanceOfType(injectionKernel.LocateByKey("ISimpleObject", 1), typeof(SimpleObjectA));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey("ISimpleObject", 2), typeof(SimpleObjectB));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey("ISimpleObject", 3), typeof(SimpleObjectC));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey("ISimpleObject", 4), typeof(SimpleObjectD));
			Assert.IsInstanceOfType(injectionKernel.LocateByKey("ISimpleObject", 5), typeof(SimpleObjectE));
		}

		[TestMethod]
		public void LocateAllInEnvironment()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>()
					                          .AsName("ISimpleObject")
					                          .InEnvironment(ExportEnvironment.RunTime);
				                          c.Export<SimpleObjectB>()
					                          .AsName("ISimpleObject")
					                          .InEnvironment(ExportEnvironment.UnitTest);
				                          c.Export<SimpleObjectC>()
					                          .AsName("ISimpleObject")
					                          .InEnvironment(ExportEnvironment.DesignTime);
			                          });

			IEnumerable<object> all = injectionKernel.LocateAll("ISimpleObject");

			Assert.IsNotNull(all);
			Assert.AreEqual(3, all.Count());
		}

		[TestMethod]
		public void Metadata()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<SimpleObjectA>()
					                          .AsName("ISimpleObject")
					                          .WithMetadata("Test", 0)
					                          .WithMetadata("Blah", 9);
				                          c.Export<SimpleObjectB>()
					                          .AsName("ISimpleObject")
					                          .WithMetadata("Test", 1)
					                          .WithMetadata("Blah", 8);
				                          c.Export<SimpleObjectC>()
					                          .AsName("ISimpleObject")
					                          .WithMetadata("Test", 2)
					                          .WithMetadata("Blah", 7);
				                          c.Export<SimpleObjectD>()
					                          .AsName("ISimpleObject")
					                          .WithMetadata("Test", 3)
					                          .WithMetadata("Blah", 6);
				                          c.Export<SimpleObjectE>()
					                          .AsName("ISimpleObject")
					                          .WithMetadata("Test", 4)
					                          .WithMetadata("Blah", 5);
			                          });

			IEnumerable<object> simpleObjects =
				injectionKernel.LocateAll("ISimpleObject",
					consider:
						(context, strategy) =>
							(int)strategy.Metadata["Test"] == 0 || (int)strategy.Metadata["Test"] == 2);

			Assert.AreEqual(2, simpleObjects.Count());
		}

		[TestMethod]
		public void WithCtorParamValueTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<WithCtorParamClass>().WithCtorParam("Hello").WithCtorParam(5);
			                          });

			WithCtorParamClass paramClass = injectionKernel.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.IsNotNull(paramClass.BasicService);
			Assert.IsNotNull(paramClass.StringParam);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(5, paramClass.IntParam);
		}

		[TestMethod]
		public void WithCtorParamValueWithNameTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<WithCtorParamClass>()
					                          .WithCtorParam("Hello", "stringParam")
					                          .WithCtorParam(5, "intParam");
			                          });

			WithCtorParamClass paramClass = injectionKernel.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.IsNotNull(paramClass.BasicService);
			Assert.IsNotNull(paramClass.StringParam);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(5, paramClass.IntParam);
		}

		[TestMethod]
		public void WithCtorParamFiltered()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.ExportAssembly(GetType().Assembly).ExportInterface(typeof(ISimpleObject));
				                          c.Export<ImportIEnumerableService>()
					                          .WithCtorParam<IEnumerable<ISimpleObject>>(
						                          consider: (context, strategy) => strategy.ActivationName.EndsWith("C"));
			                          });

			ImportIEnumerableService import = injectionKernel.Locate<ImportIEnumerableService>();

			Assert.IsNotNull(import);
			Assert.AreEqual(1, import.Count);
		}

		[TestMethod]
		public void WithCtorParamFuncTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<WithCtorParamClass>().WithCtorParam(() => "Hello").WithCtorParam(() => 5);
			                          });

			WithCtorParamClass paramClass = injectionKernel.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.IsNotNull(paramClass.BasicService);
			Assert.IsNotNull(paramClass.StringParam);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(5, paramClass.IntParam);
		}

		[TestMethod]
		public void WithCtorParamFuncWithNameTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<WithCtorParamClass>()
					                          .WithCtorParam(() => "Hello", "stringParam")
					                          .WithCtorParam(() => 5, "intParam");
			                          });

			WithCtorParamClass paramClass = injectionKernel.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.IsNotNull(paramClass.BasicService);
			Assert.IsNotNull(paramClass.StringParam);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(5, paramClass.IntParam);
		}

		[TestMethod]
		public void ImportConstructor()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export<BasicService>().As<IBasicService>();
				                          c.Export<MultipleConstructorImport>()
					                          .ImportConstructor(() => new MultipleConstructorImport(null));
				                          c.Export<ConstructorImportService>().As<IConstructorImportService>();
			                          });

			MultipleConstructorImport import = injectionKernel.Locate<MultipleConstructorImport>();

			Assert.IsNotNull(import);
			Assert.IsNotNull(import.BasicService);
			Assert.IsNull(import.ConstructorImportService);
		}

		[TestMethod]
		public void ExportPropertyTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(
				c => c.Export<ExportPropertyService>().As<IExportPropertyService>().ExportProperty(p => p.BasicService));

			IBasicService basicService = container.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void ExportPropertySingletonTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<ExportPropertyService>().
				As<IExportPropertyService>().
				ExportProperty(p => p.BasicService).
				AndSingleton());

			IBasicService basicService = container.Locate<IBasicService>();
			IBasicService secondService = container.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
			Assert.IsNotNull(secondService);

			Assert.IsTrue(ReferenceEquals(basicService, secondService));
		}

		[TestMethod]
		public void CleanupDelegateTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			bool cleanupFired = false;
			bool disposed = false;

			container.Configure(
				c => c.Export<DisposableService>().As<IDisposableService>().DisposalCleanupDelegate(x => cleanupFired = true));

			IDisposableService disposableService = container.Locate<IDisposableService>();

			disposableService.Disposing += (sender, args) => disposed = true;

			container.Dispose();

			Assert.IsTrue(cleanupFired);
			Assert.IsTrue(disposed);
		}
	}
}