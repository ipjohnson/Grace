﻿using System;
using System.Linq;
using Grace.DependencyInjection;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection
{
	[TestClass]
	public class BasicContainerTests
	{
		[TestMethod]
		public void BlackOutListTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.BlackListExportType(typeof(BasicService));

			container.Configure(
				ioc => ioc.Export<BasicService>().As<IBasicService>());

			IBasicService basicService = container.Locate<IBasicService>();

			Assert.IsNull(basicService);
		}

		[TestMethod]
		public void BlackOutListByNameTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.BlackListExport(typeof(BasicService).FullName);

			container.Configure(
				ioc => ioc.Export<BasicService>().As<IBasicService>());

			IBasicService basicService = container.Locate<IBasicService>();

			Assert.IsNull(basicService);
		}

		[TestMethod]
		public void SimpleRegistrationTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<BasicService>().As<IBasicService>().AndSingleton());

			IBasicService basicService = container.RootScope.Locate<IBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void TransientRegistrationTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(
				c =>
				{
					c.Export<BasicService>().As<IBasicService>().AndSingleton();
					c.Export<Transient>().As<ITransient>().ImportProperty(x => x.BasicService);
				});

			ITransient transient = container.RootScope.Locate<ITransient>();

			Assert.IsNotNull(transient);
			Assert.IsNotNull(transient.BasicService);
		}

		[TestMethod]
		public void FilterRunTime()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(ExportEnvironment.RunTime);

			container.Configure(c =>
									  {
										  c.Export<SimpleObjectA>().As<ISimpleObject>().InEnvironment(ExportEnvironment.RunTimeOnly);
										  c.Export<SimpleObjectB>().As<ISimpleObject>().InEnvironment(ExportEnvironment.UnitTestOnly);
										  c.Export<SimpleObjectC>().As<ISimpleObject>().InEnvironment(ExportEnvironment.DesignTimeOnly);
									  });

			ISimpleObject simpleObject = container.Locate<ISimpleObject>();

			Assert.IsNotNull(simpleObject);
			Assert.IsInstanceOfType(simpleObject, typeof(SimpleObjectA));

			Assert.AreEqual(1, container.RootScope.GetStrategies(typeof(ISimpleObject)).Count());
		}

		[TestMethod]
		public void FilterUnitTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(ExportEnvironment.UnitTest);

			container.Configure(c =>
									  {
										  c.Export<SimpleObjectA>().As<ISimpleObject>().InEnvironment(ExportEnvironment.RunTimeOnly);
										  c.Export<SimpleObjectB>().As<ISimpleObject>().InEnvironment(ExportEnvironment.UnitTestOnly);
										  c.Export<SimpleObjectC>().As<ISimpleObject>().InEnvironment(ExportEnvironment.DesignTimeOnly);
									  });

			ISimpleObject simpleObject = container.Locate<ISimpleObject>();

			Assert.IsNotNull(simpleObject);
			Assert.IsInstanceOfType(simpleObject, typeof(SimpleObjectB));

			Assert.AreEqual(1, container.RootScope.GetStrategies(typeof(ISimpleObject)).Count());
		}

		[TestMethod]
		public void FilterDesignTime()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(ExportEnvironment.DesignTime);

			container.Configure(c =>
									  {
										  c.Export<SimpleObjectA>().As<ISimpleObject>().InEnvironment(ExportEnvironment.RunTimeOnly);
										  c.Export<SimpleObjectB>().As<ISimpleObject>().InEnvironment(ExportEnvironment.UnitTestOnly);
										  c.Export<SimpleObjectC>().As<ISimpleObject>().InEnvironment(ExportEnvironment.DesignTimeOnly);
									  });

			ISimpleObject simpleObject = container.Locate<ISimpleObject>();

			Assert.IsNotNull(simpleObject);
			Assert.IsInstanceOfType(simpleObject, typeof(SimpleObjectC));

			Assert.AreEqual(1, container.RootScope.GetStrategies(typeof(ISimpleObject)).Count());
		}

		[TestMethod]
		public void MissingExportTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			container.ResolveUnknownExports += (sender, args) => { args.ExportedValue = new BasicService(); };

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void MissingExportFromChildScopeTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			container.ResolveUnknownExports += (sender, args) => { args.ExportedValue = new BasicService(); };

			IInjectionScope childScope = container.CreateChildScope();

			IImportConstructorService constructorService = childScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void AutoCreateTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<BasicService>().As<IBasicService>());

			ImportConstructorService constructorService = container.Locate<ImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void ExceptionThrownTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer { ThrowExceptions = true };

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			IImportConstructorService constructorService = null;
			bool exceptionThrown = false;

			try
			{
				constructorService = container.Locate<IImportConstructorService>();
			}
			catch (Exception)
			{
				exceptionThrown = true;
			}

			Assert.IsNull(constructorService);
			Assert.IsTrue(exceptionThrown);
		}

		[TestMethod]
		public void ExceptionNotThrownTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer { ThrowExceptions = false };

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			IImportConstructorService constructorService = null;
			bool exceptionThrown = false;

			try
			{
				constructorService = container.Locate<IImportConstructorService>();
			}
			catch (Exception)
			{
				exceptionThrown = true;
			}

			Assert.IsNull(constructorService);
			Assert.IsFalse(exceptionThrown);
		}

		[TestMethod]
		public void InjectContainerTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<DependencyInjectionContainerImportService>());

			DependencyInjectionContainerImportService service = container.Locate<DependencyInjectionContainerImportService>();

			Assert.IsNotNull(service);
			Assert.IsNotNull(service.Container);
			Assert.AreSame(container, service.Container);
		}

		[TestMethod]
		public void InjectionContextResolveTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.Export<BasicService>().As<IBasicService>());

			InjectionContext context = new InjectionContext(container.RootScope)
			                           {
				                           {"stringParam","Hello"},
													{"intParam",(x,y) => 7}
			                           };

			WithCtorParamClass paramClass = container.Locate<WithCtorParamClass>(context);

			Assert.IsNotNull(paramClass);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(7, paramClass.IntParam);
		}
	}
}