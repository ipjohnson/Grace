﻿using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection
{
	[TestClass]
	public class SecondaryDependencyResolverTests
	{
		[TestMethod]
		public void BasicResolverTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			container.AddSecondaryLocator(resolver);
			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			resolver.AddResolveValue((IBasicService)new BasicService());

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void ResolveFromChildScope()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			container.AddSecondaryLocator(resolver);
			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			resolver.AddResolveValue((IBasicService)new BasicService());

			IInjectionScope childScope = container.CreateChildScope();

			IImportConstructorService constructorService = childScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
		}

		[TestMethod]
		public void ResolveValueTypeTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			container.AddSecondaryLocator(resolver);
			container.Configure(c => c.Export<WithCtorParamClass>());

			resolver.AddResolveValue(() => (IBasicService)new BasicService());
			resolver.AddResolveValue("stringParam", "Hello");
			resolver.AddResolveValue("intParam", 10);

			WithCtorParamClass paramClass = container.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(10, paramClass.IntParam);
		}

		[TestMethod]
		public void ResolveValueTypeFromChildTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			container.AddSecondaryLocator(resolver);
			container.Configure(c => c.Export<WithCtorParamClass>());

			resolver.AddResolveValue(() => (IBasicService)new BasicService());
			resolver.AddResolveValue("stringParam", "Hello");
			resolver.AddResolveValue("intParam", 10);

			WithCtorParamClass paramClass = container.Locate<WithCtorParamClass>();

			Assert.IsNotNull(paramClass);
			Assert.AreEqual("Hello", paramClass.StringParam);
			Assert.AreEqual(10, paramClass.IntParam);
		}
	}
}