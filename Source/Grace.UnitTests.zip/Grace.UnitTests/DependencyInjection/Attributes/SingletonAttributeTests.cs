﻿using Grace.DependencyInjection.Attributes;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class SingletonAttributeTests
	{
		[TestMethod]
		public void ProvideLifeCycle()
		{
			SingletonAttribute attribute = new SingletonAttribute();

			object lifecycle = attribute.ProvideLifeCycle(typeof(BasicService));

			Assert.IsNotNull(lifecycle);
			Assert.IsInstanceOfType(lifecycle, typeof(SingletonContainer));
		}
	}
}