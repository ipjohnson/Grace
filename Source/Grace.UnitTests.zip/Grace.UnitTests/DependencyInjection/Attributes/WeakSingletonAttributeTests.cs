﻿using Grace.DependencyInjection.Attributes;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class WeakSingletonAttributeTests
	{
		[TestMethod]
		public void ProvideLifeCycle()
		{
			WeakSingletonAttribute attribute = new WeakSingletonAttribute();

			object container = attribute.ProvideLifeCycle(typeof(BasicService));

			Assert.IsNotNull(container);
			Assert.IsInstanceOfType(container, typeof(WeakSingletonContainer));
		}
	}
}