﻿using Grace.DependencyInjection.Attributes;
using Grace.DependencyInjection.Attributes.Interfaces;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class ImportAttributeTests
	{
		[TestMethod]
		public void TypeImportTest()
		{
			ImportAttribute importAttribute = new ImportAttribute();

			ImportAttributeInfo info =
				importAttribute.ProvideImportInfo(typeof(IBasicService), "Property");

			Assert.IsNotNull(info);
			Assert.IsNull(info.ImportName);
			Assert.IsNull(info.ImportKey);
			Assert.IsTrue(info.IsRequired);
		}

		[TestMethod]
		public void NameImportTest()
		{
			string name = "TestName";
			ImportAttribute importAttribute = new ImportAttribute { Name = name };

			ImportAttributeInfo info =
				importAttribute.ProvideImportInfo(typeof(IBasicService), "Property");

			Assert.IsNotNull(info);
			Assert.AreEqual(name, info.ImportName);
			Assert.IsNull(info.ImportKey);
			Assert.IsTrue(info.IsRequired);
		}

		[TestMethod]
		public void RequiredTest()
		{
			ImportAttribute importAttribute = new ImportAttribute { Required = false };

			ImportAttributeInfo info =
				importAttribute.ProvideImportInfo(typeof(IBasicService), "Property");

			Assert.IsNotNull(info);
			Assert.IsNull(info.ImportName);
			Assert.IsNull(info.ImportKey);
			Assert.IsFalse(info.IsRequired);
		}

		[TestMethod]
		public void ImportKeyTest()
		{
			ImportAttribute importAttribute = new ImportAttribute { Key = 5 };

			ImportAttributeInfo info =
				importAttribute.ProvideImportInfo(typeof(IBasicService), "Property");

			Assert.IsNotNull(info);
			Assert.IsNull(info.ImportName);
			Assert.AreEqual(5, info.ImportKey);
			Assert.IsTrue(info.IsRequired);
		}
	}
}