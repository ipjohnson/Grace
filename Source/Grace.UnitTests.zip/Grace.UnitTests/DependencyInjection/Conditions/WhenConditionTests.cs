﻿using Grace.DependencyInjection;
using Grace.DependencyInjection.Conditions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Conditions
{
	[TestClass]
	public class WhenConditionTests
	{
		[TestMethod]
		public void ConditionMeetTest()
		{
			WhenCondition condition = new WhenCondition((x, y, z) => y.GetExtraData("A") != null);
			InjectionContext context = new InjectionContext(null, null);

			Assert.IsFalse(condition.ConditionMeet(null, context, null));

			context.SetExtraData("A", true);

			Assert.IsTrue(condition.ConditionMeet(null, context, null));
		}
	}
}