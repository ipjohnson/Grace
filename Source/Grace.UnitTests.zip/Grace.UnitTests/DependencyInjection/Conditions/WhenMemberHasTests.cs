﻿using System;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Conditions;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Conditions
{
	[TestClass]
	public class WhenMemberHasTests
	{
		[TestMethod]
		public void ConditionMeetTest()
		{
			WhenMemberHas whenMemberHas = new WhenMemberHas(typeof(SomeTestAttribute));

			InjectionTargetInfo targetInfo =
				new InjectionTargetInfo(typeof(ImportPropertyService),
					new Attribute[0],
					typeof(ImportPropertyService).GetProperty("BasicService"),
					new Attribute[0],
					new Attribute[] { new SomeTestAttribute() });
			bool conditionMeet =
				whenMemberHas.ConditionMeet(new FauxInjectionScope(),
					new InjectionContext(null, new FauxInjectionScope()) { TargetInfo = targetInfo },
					new FauxExportStrategy(() => new ImportPropertyService()));

			Assert.IsTrue(conditionMeet);
		}

		[TestMethod]
		public void ConditionNotMeetTest()
		{
			WhenClassHas whenMemberHas = new WhenClassHas(typeof(SomeTestAttribute));

			InjectionTargetInfo targetInfo =
				new InjectionTargetInfo(typeof(ImportPropertyService),
					new Attribute[0],
					typeof(ImportPropertyService).GetProperty("BasicService"),
					new Attribute[0],
					new Attribute[0]);

			bool conditionMeet =
				whenMemberHas.ConditionMeet(new FauxInjectionScope(),
					new InjectionContext(null, new FauxInjectionScope()),
					new FauxExportStrategy(() => new ImportPropertyService()));

			Assert.IsFalse(conditionMeet);

			conditionMeet =
				whenMemberHas.ConditionMeet(new FauxInjectionScope(),
					new InjectionContext(null, new FauxInjectionScope()) { TargetInfo = targetInfo },
					new FauxExportStrategy(() => new ImportPropertyService()));

			Assert.IsFalse(conditionMeet);
		}
	}
}