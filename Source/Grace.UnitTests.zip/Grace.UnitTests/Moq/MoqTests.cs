﻿using System;
using Grace.DependencyInjection;
using Grace.Moq;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Xunit;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace Grace.UnitTests.Moq
{
	[TestClass]
	public class MoqTests
	{
		[Fact]
		public void AutoMoqContainerTest()
		{
			MoqContainer container = new MoqContainer();

			ImportConstructorService service = container.Locate<ImportConstructorService>();

			Assert.IsNotNull(service);
			Assert.IsNotNull(service.BasicService);
		}

		[TestMethod]
		public void AutoMoqSetupTest()
		{
			MoqContainer container = new MoqContainer();

			ImportConstructorService service = container.Locate<ImportConstructorService>();

			container.Locate<Mock<IBasicService>>().Setup(x => x.TestMethod()).Returns(5);

			Assert.IsNotNull(service);
			Assert.AreEqual(5, service.TestMethod());
		}

		[TestMethod]
		public void MoqContainerSetupTest()
		{
			MoqContainer container = new MoqContainer();

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			container.Locate<Mock<IBasicService>>().Setup(x => x.TestMethod()).Returns(5);

			IImportConstructorService service = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(service);
			Assert.AreEqual(5, service.TestMethod());

			container.Locate<Mock<IBasicService>>().Verify(x => x.TestMethod(), Times.Once);
		}

		[TestMethod]
		public void MoqExtensionTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Moq();

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			container.Locate<Mock<IBasicService>>().Setup(x => x.TestMethod()).Returns(5);

			IImportConstructorService service = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(service);
			Assert.AreEqual(5, service.TestMethod());

			container.Locate<Mock<IBasicService>>().Verify(x => x.TestMethod(), Times.Once);
		}

		[TestMethod]
		public void RegisterTransientMock()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Moq<IBasicService>().Setup(m => m.Setup(x => x.TestMethod()).Returns(5));
			                    });

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
			Assert.IsNotNull(constructorService.BasicService);
			Assert.AreEqual(5, constructorService.BasicService.TestMethod());

			Assert.AreEqual(5, container.Locate<IBasicService>().TestMethod());

			Assert.IsFalse(ReferenceEquals(constructorService.BasicService, container.Locate<IBasicService>()));
		}

		[TestMethod]
		public void RegisterSingletonMock()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Moq<IBasicService>().Setup(m => m.Setup(x => x.TestMethod()).Returns(5)).AndSingleton();
			                    });

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
			Assert.AreEqual(5, constructorService.TestMethod());

			Assert.IsTrue(ReferenceEquals(constructorService.BasicService, container.Locate<IBasicService>()));
		}

		[TestMethod]
		public void VerifyMock()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Moq();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Moq<IBasicService>().
					                    Setup(m => m.Setup(x => x.TestMethod()).Returns(5)).
					                    Verify(m => m.Verify(b => b.TestMethod(), Times.Once)).
					                    AndSingleton();
			                    });

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);
			Assert.AreEqual(5, constructorService.TestMethod());

			container.Verify();
		}

		[TestMethod]
		public void VerifyFailMock()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Moq();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Moq<IBasicService>().
					                    Setup(m => m.Setup(x => x.TestMethod()).Returns(5)).
					                    Verify(m => m.Verify(b => b.TestMethod(), Times.Once)).
					                    AndSingleton();
			                    });

			IImportConstructorService constructorService = container.Locate<IImportConstructorService>();

			Assert.IsNotNull(constructorService);

			constructorService.TestMethod();
			constructorService.TestMethod();

			try
			{
				container.Verify();

				throw new Exception("Should have thrown a mock exception and failed");
			}
			catch (MockException exp)
			{
			}
		}
	}
}