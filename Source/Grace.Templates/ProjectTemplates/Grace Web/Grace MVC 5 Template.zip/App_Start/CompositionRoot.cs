using Grace.DependencyInjection;
using Grace.MVC.DependencyInjection;
using Grace.MVC.Extensions;

namespace $safeprojectname$
{
	public class CompositionRoot : IConfigurationModule
	{
		public void Configure(IExportRegistrationBlock registrationBlock)
		{
			// Configure Framework
			registrationBlock.Export<DisposalScopeControllerActivator>().ByInterfaces();
			registrationBlock.Export<WebSharedPerRequestLifestyleProvider>().ByInterfaces();
			
			// Export controllers 
			registrationBlock.ExportController(Types.FromThisAssembly());

			// Setup ILog interface so it can be imported, it uses the InjectionType property to get the correct logger type
			registrationBlock.ExportInstance((scope, context) => context.TargetInfo != null ?
																							  log4net.LogManager.GetLogger(context.TargetInfo.InjectionType) :
																							  log4net.LogManager.GetLogger(string.Empty));

			// Scan assembly for attributed types
			// container.Configure(c => c.Export(Types.FromThisAssembly()));
		}
	}
}