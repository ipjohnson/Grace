using Grace.DependencyInjection;

namespace $safeprojectname$
{
	public class CompositionRoot : IConfigurationModule
	{
		public void Configure(IExportRegistrationBlock registrationBlock)
		{
			
		}
	}
}