using System.Web.Mvc;
using Grace.DependencyInjection;
using Grace.MVC.DependencyInjection;
using Grace.MVC.Extensions;

namespace $safeprojectname$
{
	public class DependencyInjectionConfig 
	{
		public static void RegisterContainer()
		{
			IDependencyInjectionContainer container = ConfigureContainer();

			DependencyResolver.SetResolver(new GraceDependencyResolver(container));
		}

		private static IDependencyInjectionContainer ConfigureContainer()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(
																			disposalScopeProvider: new MVCDisposalScopeProvider());

			container.Configure(new CompositionRoot());

			return container;
		}
	}
}