using Grace.DependencyInjection;

namespace $safeprojectname$
{
	public class DependencyInjectionConfig 
	{
		public void RegisterContainer()
		{
			
		}
	}
}