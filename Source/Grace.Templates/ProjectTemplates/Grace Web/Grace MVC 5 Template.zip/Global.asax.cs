﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Grace.DependencyInjection;
using Grace.log4net;
using Grace.Logging;
using Grace.MVC.DependencyInjection;
using Grace.MVC.Extensions;
using log4net.Config;

namespace $safeprojectname$
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

			  	SetupLogging();

			   DependencyInjectionConfig.RegisterContainer();
        }

		  private void SetupLogging()
		  {
			   // Configure from web.config
			   XmlConfigurator.Configure();

   			Logger.SetLogService(new LogService());
		  }
    }
}
