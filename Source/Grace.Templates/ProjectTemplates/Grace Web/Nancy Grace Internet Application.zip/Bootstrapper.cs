﻿
namespace $safeprojectname$
{
	using Nancy;
	using Nancy.Bootstrappers.Grace;

	public class Bootstrapper : GraceNancyBootstrapper
	{
		// The bootstrapper enables you to reconfigure the composition of the framework,
		// by overriding the various methods and properties.
		// For more information https://github.com/NancyFx/Nancy/wiki/Bootstrapper
	}
}