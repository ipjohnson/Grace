﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using Grace.DependencyInjection;
using Grace.log4net;
using Grace.Logging;
using Grace.WCF;
using Grace.WCF.DependencyInjection;
using log4net.Config;

namespace $safeprojectname$
{
	public class Global : System.Web.HttpApplication
	{
		protected void Application_Start(object sender, EventArgs e)
		{
			SetupLogging();

			SetupContainer();
		}

		private void SetupLogging()
		{
			// Configure from web.config
			XmlConfigurator.Configure();

			Logger.SetLogService(new LogService());
		}

		private void SetupContainer()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(
																				disposalScopeProvider: new WCFDisposalScopeProvider());

			// configure the container to provide singleton per request for WCF services
			container.Configure(c => c.Export<WCFSharedPerRequestLifestyleProvider>().ByInterfaces());

			// Setup ILog interface so it can be imported, it uses the InjectionType property to get the correct logger type
			container.Configure(c => c.ExportInstance((scope, context) => context.TargetInfo != null ? 
																							  log4net.LogManager.GetLogger(context.TargetInfo.InjectionType) :
																							  log4net.LogManager.GetLogger(string.Empty)));
			
			// Uncomment to scan assembly for classes with export attributes
			// container.Configure(c => c.Export(Types.FromThisAssembly()));

			DefaultExportLocator.Instance = container;
		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{

		}
	}
}