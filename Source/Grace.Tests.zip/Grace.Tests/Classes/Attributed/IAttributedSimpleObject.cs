﻿namespace Grace.UnitTests.Classes.Attributed
{
	public interface IAttributedSimpleObject
	{
	}
}