﻿using Grace.DependencyInjection.Attributes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.Classes.Attributed
{
	public interface IAttributeImportConstructorService
	{
	}

	[Export(typeof(IAttributeImportConstructorService))]
	public class AttributeImportConstructorService : IAttributeImportConstructorService
	{
		public AttributeImportConstructorService(IAttributeBasicService basicService)
		{
			Assert.IsNotNull(basicService);
		}
	}
}