﻿namespace Grace.UnitTests.Classes.Simple
{
	public class ImportPropertySimpleObject
	{
		public ISimpleObject SimpleObject { get; set; }
	}
}