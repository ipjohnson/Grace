﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.Classes.Simple
{
	public class ImportReadOnlyCollectionService
	{
		public ImportReadOnlyCollectionService(IReadOnlyCollection<ISimpleObject> simpleObjects)
		{
			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}
	}
}