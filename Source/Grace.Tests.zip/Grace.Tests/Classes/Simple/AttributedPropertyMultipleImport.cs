﻿namespace Grace.UnitTests.Classes.Simple
{
	public class AttributedPropertyMultipleImport
	{
		[SomeTest]
		public ISimpleObject[] SimpleObjects { get; set; }
	}
}