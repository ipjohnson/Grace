﻿namespace Grace.UnitTests.Classes.Simple
{
	public class BaseClass
	{
	}

	public class SomeClass
	{
	}

	public class OtherClass
	{
	}
}