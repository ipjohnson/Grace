﻿using System.Threading.Tasks;
using Grace.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.Utilities
{
	[TestClass]
	public class TaskHelperTests
	{
		[TestMethod]
		public void EmptyTaskTest()
		{
			Task emptyTask = TaskHelper.CreateEmptyTask();

			Assert.IsNotNull(emptyTask);

			Assert.AreEqual(TaskStatus.RanToCompletion, emptyTask.Status);
		}

		[TestMethod]
		public void ReturnNullTaskHelper()
		{
			Task<string> nullTask = TaskHelper.NullTask<string>();

			Assert.IsNotNull(nullTask);

			Assert.AreEqual(TaskStatus.RanToCompletion, nullTask.Status);

			Assert.IsNull(nullTask.Result);
		}

		[TestMethod]
		public void ReturnValueTaskHelper()
		{
			Task<string> stringTask = TaskHelper.ReturnTask("Hello");

			Assert.IsNotNull(stringTask);

			Assert.AreEqual(TaskStatus.RanToCompletion, stringTask.Status);

			Assert.AreEqual("Hello", stringTask.Result);
		}
	}
}