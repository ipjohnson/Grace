﻿using Grace.DependencyInjection;
using Grace.NSubstitute;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace Grace.UnitTests.NSubstitute
{
	[TestClass]
	public class NSubstituteTests
	{
		[TestMethod]
		public void ResolveTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Substitute();

			container.Configure(c => c.Export<ImportConstructorService>().As<IImportConstructorService>());

			container.Locate<IBasicService>().TestMethod().Returns(5);
			container.Locate<IBasicService>().Count.Returns(5);

			IImportConstructorService importConstructorService =
				container.Locate<IImportConstructorService>();

			Assert.IsNotNull(importConstructorService);
			Assert.IsNotNull(importConstructorService.BasicService);

			Assert.AreEqual(5, importConstructorService.BasicService.Count);
			Assert.AreEqual(5, importConstructorService.BasicService.TestMethod());
		}

		[TestMethod]
		public void SubstituteSingletonTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Substitute<IBasicService>().AndSingleton();
			                    });

			container.Locate<IBasicService>().TestMethod().Returns(5);
			container.Locate<IBasicService>().Count.Returns(5);

			IImportConstructorService importConstructorService =
				container.Locate<IImportConstructorService>();

			Assert.IsNotNull(importConstructorService);
			Assert.IsNotNull(importConstructorService.BasicService);

			Assert.AreEqual(5, importConstructorService.BasicService.Count);
			Assert.AreEqual(5, importConstructorService.BasicService.TestMethod());
		}

		[TestMethod]
		public void SubstituteTransientTest()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c =>
			                    {
				                    c.Export<ImportConstructorService>().As<IImportConstructorService>();
				                    c.Substitute<IBasicService>().Setup(service => service.Count.Returns(5));
			                    });

			IImportConstructorService importConstructorService =
				container.Locate<IImportConstructorService>();

			Assert.IsNotNull(importConstructorService);
			Assert.IsNotNull(importConstructorService.BasicService);

			Assert.AreEqual(5, importConstructorService.BasicService.Count);

			Assert.IsFalse(ReferenceEquals(importConstructorService.BasicService, container.Locate<IBasicService>()));
		}

		[TestMethod]
		public void SubstituteMultiple()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Substitute();

			container.Configure(c => c.Export<ImportIEnumerableService>().As<IImportIEnumerableService>());

			IImportIEnumerableService iEnumerableService = container.Locate<IImportIEnumerableService>();

			Assert.IsNotNull(iEnumerableService);
			Assert.AreEqual(1, iEnumerableService.Count);
		}
	}
}