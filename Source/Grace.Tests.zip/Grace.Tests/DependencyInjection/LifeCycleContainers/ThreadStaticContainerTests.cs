﻿using System.Threading.Tasks;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.LifeCycleContainers
{
	[TestClass]
	public class ThreadStaticContainerTests
	{
		[TestMethod]
		public void TransientTest()
		{
			ThreadStaticContainer container = new ThreadStaticContainer();

			Assert.IsFalse(container.Transient);
		}

		[TestMethod]
		public void CloneTest()
		{
			ThreadStaticContainer container = new ThreadStaticContainer();

			ILifeCycleContainer clone = container.Clone();

			Assert.IsNotNull(clone);
			Assert.IsInstanceOfType(clone, typeof(ThreadStaticContainer));
		}

		[TestMethod]
		public void ShareTest()
		{
			ThreadStaticContainer container = new ThreadStaticContainer();

			object instance = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsNotNull(instance);

			object instance2 = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsTrue(ReferenceEquals(instance, instance2));
		}

		[TestMethod]
		public void SeparatePerThread()
		{
			ThreadStaticContainer container = new ThreadStaticContainer();

			object instance = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsNotNull(instance);

			object instance2 = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsTrue(ReferenceEquals(instance, instance2));

			Task<object> newTask = Task.Factory.StartNew(
				() => container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null));

			newTask.Wait(1000);

			Assert.IsTrue(newTask.IsCompleted);
			Assert.IsFalse(ReferenceEquals(instance, newTask.Result));
		}

		[TestMethod]
		public void Dispose()
		{
			ThreadStaticContainer container = new ThreadStaticContainer();

			DisposableService instance =
				(DisposableService)
					container.Locate((x, y) => new DisposableService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsNotNull(instance);

			bool instanceDisposed = false;
			bool instance2Disposed = false;

			instance.Disposing += (sender, args) => instanceDisposed = true;

			Task<DisposableService> waitTask = Task.Factory.StartNew(() =>
				(DisposableService)
					container.Locate((x, y) => new DisposableService(),
						new FauxInjectionScope(),
						new FauxInjectionContext(),
						null));

			waitTask.Wait(1000);

			waitTask.Result.Disposing += (sender, args) => instance2Disposed = true;

			container.Dispose();

			Assert.IsTrue(instanceDisposed);
			Assert.IsTrue(instance2Disposed);
		}
	}
}