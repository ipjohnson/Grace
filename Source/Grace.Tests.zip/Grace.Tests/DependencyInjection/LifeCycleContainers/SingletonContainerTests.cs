﻿using System.Linq.Expressions;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.LifeCycleContainers
{
	[TestClass]
	public class SingletonContainerTests
	{
		[TestMethod]
		public void TransientTest()
		{
			SingletonContainer container = new SingletonContainer();

			Assert.IsFalse(container.Transient);
		}

		[TestMethod]
		public void CloneTest()
		{
			SingletonContainer container = new SingletonContainer();

			ILifeCycleContainer clone = container.Clone();

			Assert.IsNotNull(clone);
			Assert.IsInstanceOfType(clone, typeof(SingletonContainer));
		}

		[TestMethod]
		public void ShareTest()
		{
			SingletonContainer container = new SingletonContainer();

			object instance = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), new FauxExportStrategy(() => new object()));

			Assert.IsNotNull(instance);

			object instance2 = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), new FauxExportStrategy(() => new object()));

			Assert.IsTrue(ReferenceEquals(instance, instance2));
		}

		[TestMethod]
		public void DisposeTest()
		{
			SingletonContainer container = new SingletonContainer();

			IDisposableService disposableService =
				(IDisposableService)
					container.Locate((x, y) => new DisposableService(), 
										  new FauxInjectionScope(),
										  new FauxInjectionContext(),
										  new FauxExportStrategy(() => new object()));

			bool eventCalled = false;

			disposableService.Disposing += (sender, args) => eventCalled = true;

			container.Dispose();

			Assert.IsTrue(eventCalled);
		}
	}
}