﻿using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.LifeCycleContainers
{
	[TestClass]
	public class SingletonPerScopeContainerTests
	{
		[TestMethod]
		public void DisposeTest()
		{
			SingletonPerScopeContainer container = new SingletonPerScopeContainer();
			FauxInjectionScope fauxInjectionScope = new FauxInjectionScope();

			bool eventFired = false;

			object locatedObject =
				container.Locate((scope, context) =>
				                 {
					                 DisposableService disposableService = new DisposableService();

					                 disposableService.Disposing += (sender, args) => eventFired = true;

					                 return disposableService;
				                 },
					fauxInjectionScope,
					new FauxInjectionContext { RequestingScope = fauxInjectionScope },
					new FauxExportStrategy(() => new object()));

			Assert.IsNotNull(locatedObject);

			container.Dispose();

			Assert.IsFalse(eventFired);

			fauxInjectionScope.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void TransientTest()
		{
			SingletonPerScopeContainer container = new SingletonPerScopeContainer();

			Assert.IsFalse(container.Transient);
		}

		[TestMethod]
		public void CloneTest()
		{
			SingletonPerScopeContainer container = new SingletonPerScopeContainer();

			ILifeCycleContainer clone = container.Clone();

			Assert.IsNotNull(clone);
			Assert.IsInstanceOfType(clone, typeof(SingletonPerScopeContainer));
		}

		[TestMethod]
		public void SharedTest()
		{
			SingletonPerScopeContainer container = new SingletonPerScopeContainer();
			FauxInjectionScope requestingScope = new FauxInjectionScope();

			IBasicService basicService = (IBasicService)
				container.Locate((x, y) => new BasicService(),
					new FauxInjectionScope(),
					new FauxInjectionContext { RequestingScope = requestingScope },
					new FauxExportStrategy(() => 0));

			IBasicService testService = (IBasicService)
				container.Locate((x, y) => new BasicService(),
					new FauxInjectionScope(),
					new FauxInjectionContext { RequestingScope = requestingScope },
					new FauxExportStrategy(() => 0));

			Assert.IsTrue(ReferenceEquals(basicService, testService));
		}
	}
}