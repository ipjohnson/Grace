﻿using System;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.LifeCycleContainers
{
	[TestClass]
	public class WeakReferenceContainerTests
	{
		[TestMethod]
		public void DisposeTest()
		{
			WeakSingletonContainer container = new WeakSingletonContainer();

			container.Dispose();
		}

		[TestMethod]
		public void TransientTest()
		{
			WeakSingletonContainer container = new WeakSingletonContainer();

			Assert.IsFalse(container.Transient);
		}

		[TestMethod]
		public void CloneTest()
		{
			WeakSingletonContainer container = new WeakSingletonContainer();

			ILifeCycleContainer clone = container.Clone();

			Assert.IsNotNull(clone);
			Assert.IsInstanceOfType(clone, typeof(WeakSingletonContainer));
		}

		[TestMethod]
		public void ShareTest()
		{
			WeakSingletonContainer container = new WeakSingletonContainer();

			object basicService = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsNotNull(basicService);

			object basicService2 = container.Locate((x, y) => new BasicService(), new FauxInjectionScope(), new FauxInjectionContext(), null);

			Assert.IsTrue(ReferenceEquals(basicService, basicService2));
		}

		[TestMethod]
		public void WeakReferenceTest()
		{
			WeakSingletonContainer container = new WeakSingletonContainer();

			int count = GetBasicServiceCount(container, 1);

			GC.Collect();
			GC.WaitForPendingFinalizers();

			int count2 = GetBasicServiceCount(container, 2);

			Assert.AreEqual(2, count2);
		}

		private int GetBasicServiceCount(WeakSingletonContainer container, int count)
		{
			IBasicService basicService = (IBasicService)container.Locate(
				(x, y) => new BasicService { Count = count },
				new FauxInjectionScope(),
				new FauxInjectionContext(),
				null);

			Assert.IsNotNull(basicService);

			return basicService.Count;
		}
	}
}