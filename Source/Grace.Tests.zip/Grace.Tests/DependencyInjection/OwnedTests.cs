﻿using Grace.DependencyInjection;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection
{
	[TestClass]
	public class OwnedTests
	{
		[TestMethod]
		public void SimpleNonDisposableTest()
		{
			Owned<IBasicService> owned = new Owned<IBasicService>();
			BasicService basicService = new BasicService();

			owned.SetValue(basicService);

			Assert.IsTrue(ReferenceEquals(owned.Value, basicService));

			owned.Dispose();
		}

		[TestMethod]
		public void SimpleDisposableTest()
		{
			Owned<IDisposableService> owned = new Owned<IDisposableService>();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			owned.SetValue(disposableService);

			Assert.IsTrue(ReferenceEquals(owned.Value, disposableService));

			owned.Dispose();

			Assert.IsTrue(eventFired);
		}
	}
}