﻿using System;
using Grace.DependencyInjection.Conditions;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Conditions
{
	[TestClass]
	public class WhenInjectedIntoConditionTests
	{
		[TestMethod]
		public void ConditionMeetTest()
		{
			WhenInjectedInto condition = new WhenInjectedInto(typeof(ImportPropertyService));

			bool conditionMeet =
				condition.ConditionMeet(new FauxInjectionScope(),
					new FauxInjectionContext
					{
						TargetInfo =
							new InjectionTargetInfo(typeof(ImportPropertyService),
							new Attribute[0],
							typeof(ImportPropertyService).GetProperty("BasicService"),
							new Attribute[0],
							new Attribute[0])
					},
					new FauxExportStrategy(() => new object()));

			Assert.IsTrue(conditionMeet);
		}

		[TestMethod]
		public void ConditionNotMeetTest()
		{
			WhenInjectedInto condition = new WhenInjectedInto(typeof(ImportPropertyService));

			bool conditionMeet =
				condition.ConditionMeet(new FauxInjectionScope(),
					new FauxInjectionContext
					{
						TargetInfo =
							new FauxInjectionTargetInfo { InjectionType = typeof(ImportConstructorService) }
					},
					new FauxExportStrategy(() => new object()));

			Assert.IsFalse(conditionMeet);
		}

		[TestMethod]
		public void ConditionTargetInfoNull()
		{
			WhenInjectedInto condition = new WhenInjectedInto(typeof(ImportPropertyService));

			bool conditionMeet =
				condition.ConditionMeet(new FauxInjectionScope(),
					new FauxInjectionContext(),
					new FauxExportStrategy(() => new object()));

			Assert.IsFalse(conditionMeet);
		}
	}
}