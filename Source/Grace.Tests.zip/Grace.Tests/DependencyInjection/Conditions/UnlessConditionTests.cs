﻿using Grace.DependencyInjection;
using Grace.DependencyInjection.Conditions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Conditions
{
	[TestClass]
	public class UnlessConditionTests
	{
		[TestMethod]
		public void ConditionMeetTest()
		{
			UnlessCondition condition = new UnlessCondition((x, y, z) => y.GetExtraData("A") != null);
			InjectionContext context = new InjectionContext(null, null);

			Assert.IsTrue(condition.ConditionMeet(null, context, null));

			context.SetExtraData("A", true);

			Assert.IsFalse(condition.ConditionMeet(null, context, null));
		}
	}
}