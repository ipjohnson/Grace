﻿using System.Collections.Generic;
using System.Linq;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class InjectionKernelGenericTests
	{
		[TestMethod]
		public void BasicGenericTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export(typeof(GenericService<>)).As(typeof(IGenericService<>)));

			IGenericService<int> service = injectionKernel.Locate<IGenericService<int>>();

			Assert.IsNotNull(service);
		}

		[TestMethod]
		public void ImportGenericTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export(typeof(GenericService<>)).As(typeof(IGenericService<>));
				                          c.Export(typeof(GenericTransient<>)).As(typeof(IGenericTransient<>));
			                          });

			IGenericTransient<int> transient = injectionKernel.Locate<IGenericTransient<int>>();

			Assert.IsNotNull(transient);
			IGenericService<int> service = injectionKernel.Locate<IGenericService<int>>();

			Assert.IsNotNull(service);
		}

		[TestMethod]
		public void SingletonGenericTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.Export(typeof(GenericService<>)).As(typeof(IGenericService<>)).AndSingleton());

			IGenericService<int> serviceA = injectionKernel.Locate<IGenericService<int>>();
			IGenericService<int> serviceB = injectionKernel.Locate<IGenericService<int>>();

			Assert.IsNotNull(serviceA);
			Assert.IsNotNull(serviceB);

			Assert.IsTrue(ReferenceEquals(serviceA, serviceB));
		}

		[TestMethod]
		public void ImportGenericList()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c =>
			                          {
				                          c.Export(typeof(GenericService<>)).As(typeof(IGenericService<>));
				                          c.Export(typeof(ConstrainedService<>)).As(typeof(IGenericService<>));
			                          });

			IEnumerable<IGenericService<int>> services = injectionKernel.LocateAll<IGenericService<int>>();

			Assert.IsNotNull(services);
			Assert.AreEqual(1, services.Count());

			IEnumerable<IGenericService<IBasicService>> basicServices =
				injectionKernel.LocateAll<IGenericService<IBasicService>>();

			Assert.IsNotNull(basicServices);
			Assert.AreEqual(2, basicServices.Count());
		}
	}
}