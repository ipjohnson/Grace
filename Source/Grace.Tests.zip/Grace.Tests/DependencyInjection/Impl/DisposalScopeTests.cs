﻿using System;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class DisposalScopeTests
	{
		[TestMethod]
		public void BasicDisposalTest()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			disposalScope.AddDisposable(disposableService);

			disposalScope.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void ThrowExceptionDuringCleanUp()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			disposalScope.AddDisposable(disposableService, disposed => { throw new Exception(); });

			disposalScope.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void ThrowExceptionDuringDispose()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) =>
			                               {
				                               eventFired = true;
				                               throw new Exception();
			                               };

			disposalScope.AddDisposable(disposableService, disposed => { throw new Exception(); });

			disposalScope.Dispose();

			Assert.IsTrue(eventFired);
		}

		[TestMethod]
		public void DoubleDisposeTest()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			disposalScope.AddDisposable(disposableService);

			disposalScope.Dispose();

			Assert.IsTrue(eventFired);

			eventFired = false;

			disposalScope.Dispose();

			Assert.IsFalse(eventFired);
		}

		[TestMethod]
		public void CleanUpDelegateTest()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;
			bool cleanUpCalled = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			disposalScope.AddDisposable(disposableService,
				disposed =>
				{
					Assert.IsTrue(ReferenceEquals(disposableService, disposed));

					cleanUpCalled = true;
				});

			disposalScope.Dispose();

			Assert.IsTrue(eventFired);
			Assert.IsTrue(cleanUpCalled);
		}

		[TestMethod]
		public void RemoveFromDisposalTest()
		{
			DisposalScope disposalScope = new DisposalScope();
			DisposableService disposableService = new DisposableService();
			bool eventFired = false;

			disposableService.Disposing += (sender, args) => eventFired = true;

			disposalScope.AddDisposable(disposableService);

			disposalScope.RemoveDisposable(disposableService);

			disposalScope.Dispose();

			Assert.IsFalse(eventFired);
		}
	}
}