﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class ExportAssemblyConfigurationTests
	{
		[TestMethod]
		public void SingletonTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			Assembly assembly = GetType().Assembly;

			injectionKernel.Configure(c => c.ExportAssembly(assembly).ExportInterface(typeof(ISimpleObject)).AndSingleton());

			ISimpleObject simpleObject = injectionKernel.Locate<ISimpleObject>();

			Assert.IsNotNull(simpleObject);

			Assert.IsTrue(ReferenceEquals(simpleObject, injectionKernel.Locate<ISimpleObject>()));
		}

		[TestMethod]
		public void WeakSingletonTest()
		{
			InjectionKernelManager injectionKernelManager =
				new InjectionKernelManager(null, DependencyInjectionContainer.CompareExportStrategies, new BlackList());
			InjectionKernel injectionKernel =
				new InjectionKernel(injectionKernelManager,
					null,
					null,
					"RootScope",
					DependencyInjectionContainer.CompareExportStrategies);

			Assembly assembly = GetType().Assembly;

			injectionKernel.Configure(c => c.ExportAssembly(assembly).ExportInterface(typeof(ISimpleObject)).AndWeakSingleton());

			ISimpleObject simpleObject = injectionKernel.Locate<ISimpleObject>();

			Assert.IsNotNull(simpleObject);

			Assert.IsTrue(ReferenceEquals(simpleObject, injectionKernel.Locate<ISimpleObject>()));
		}

		[TestMethod]
		public void InEnvironment()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer(ExportEnvironment.UnitTest);

			container.Configure(c => c.ExportAssembly(GetType().Assembly).InEnvironment(ExportEnvironment.RunTimeOnly));

			IEnumerable<ISimpleObject> simpleObjects = container.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(0, simpleObjects.Count());
		}

		[TestMethod]
		public void SelectTypes()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(
				c => c.ExportAssembly(GetType().Assembly).ExportInterface(typeof(ISimpleObject)).Select(TypesThat.EndWith("C")));

			IEnumerable<ISimpleObject> simpleObjects = container.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(1, simpleObjects.Count());
		}

		[TestMethod]
		public void ExportInterfaces()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(
				c => c.ExportAssembly(GetType().Assembly).ExportInterfaces(t => t.Name.StartsWith("ISimple")));

			IEnumerable<ISimpleObject> simpleObjects = container.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(5, simpleObjects.Count());
		}

		[TestMethod]
		public void ExportInterfacesAndWhere()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(
				c => c.Export(Types.FromThisAssembly()).
					ExportInterfaces(TypesThat.StartWith("ISimple")).
					Select(TypesThat.EndWith("C")));

			IEnumerable<ISimpleObject> simpleObjects = container.LocateAll<ISimpleObject>();

			Assert.IsNotNull(simpleObjects);
			Assert.AreEqual(1, simpleObjects.Count());
		}
	}
}