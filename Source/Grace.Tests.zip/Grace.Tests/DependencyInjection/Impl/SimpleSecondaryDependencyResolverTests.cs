﻿using System.Collections.Generic;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Impl
{
	[TestClass]
	public class SimpleSecondaryDependencyResolverTests
	{
		[TestMethod]
		public void InitValueTest()
		{
			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator(
				new Dictionary<string, object>
				{
					{ "BasicService", new BasicService() }
				});

			object returnValue =
				resolver.Locate(new FauxInjectionScope(), new FauxInjectionContext(), "BasicService", null, null);

			Assert.IsNotNull(returnValue);
			Assert.IsInstanceOfType(returnValue, typeof(BasicService));
		}

		[TestMethod]
		public void RegisterInstanceByTypeTest()
		{
			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			resolver.AddResolveValue(new BasicService());

			object returnValue =
				resolver.Locate(new FauxInjectionScope(), new FauxInjectionContext(), null, typeof(BasicService), null);

			Assert.IsNotNull(returnValue);
			Assert.IsInstanceOfType(returnValue, typeof(BasicService));
		}

		[TestMethod]
		public void RegisterFuncByTypeTest()
		{
			SimpleSecondaryExportLocator resolver = new SimpleSecondaryExportLocator();

			resolver.AddResolveValue(() => new BasicService());

			object returnValue =
				resolver.Locate(new FauxInjectionScope(), new FauxInjectionContext(), null, typeof(BasicService), null);

			Assert.IsNotNull(returnValue);
			Assert.IsInstanceOfType(returnValue, typeof(BasicService));
		}
	}
}