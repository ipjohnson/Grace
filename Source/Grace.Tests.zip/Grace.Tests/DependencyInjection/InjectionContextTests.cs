﻿using System.Linq;
using System.Reflection;
using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.FauxClasses;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection
{
	[TestClass]
	public class InjectionContextTests
	{
		private const string TEST_VALUE_STRING = "TestValue";
		private const string NEW_VALUE = "NewValue";

		[TestMethod]
		public void ExtraDataTest()
		{
			InjectionContext injectionContext = new InjectionContext(null, null);

			Assert.IsNull(injectionContext.GetExtraData(TEST_VALUE_STRING));

			injectionContext.SetExtraData(TEST_VALUE_STRING, NEW_VALUE);

			Assert.AreEqual(NEW_VALUE, injectionContext.GetExtraData(TEST_VALUE_STRING));
		}

		[TestMethod]
		public void RegisterTypeExportTest()
		{
			InjectionContext injectionContext = new InjectionContext(null, null);

			IBasicService testValue = injectionContext.Locate<IBasicService>();

			Assert.IsNull(testValue);

			IBasicService newValue = new BasicService();

			injectionContext.Export((x, y) => newValue);

			testValue = injectionContext.Locate<IBasicService>();

			Assert.IsNotNull(testValue);
			Assert.IsTrue(ReferenceEquals(newValue, testValue));
		}

		[TestMethod]
		public void LocateByName()
		{
			string exportName = "Test";
			InjectionContext injectionContext = new InjectionContext(null, null);

			Assert.IsNull(injectionContext.Locate(exportName));

			injectionContext.Export(exportName, (x, y) => new BasicService());

			object locatedObject = injectionContext.Locate(exportName);

			Assert.IsNotNull(locatedObject);
		}

		[TestMethod]
		public void LocateUnknownByName()
		{
			string exportName = "Test";
			InjectionContext injectionContext = new InjectionContext(null, null);

			injectionContext.Export(exportName, (x, y) => new BasicService());

			object testO = injectionContext.Locate("Test2");

			Assert.IsNull(testO);
		}

		[TestMethod]
		public void LocateUnknownType()
		{
			InjectionContext injectionContext = new InjectionContext(null, null);

			IBasicService testValue = injectionContext.Locate<IBasicService>();

			Assert.IsNull(testValue);

			IBasicService newValue = new BasicService();

			injectionContext.Export((x, y) => newValue);

			Assert.IsNull(injectionContext.Locate<IImportConstructorService>());
		}

		[TestMethod]
		public void PropertyTargetInfoTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc =>
				{
					ioc.ExportFunc((scope, context) =>
										{
											IInjectionTargetInfo targetInfo = context.TargetInfo;

											Assert.IsNotNull(targetInfo);

											Assert.IsNotNull(targetInfo.InjectionType);
											Assert.AreEqual(typeof(ImportPropertyService), targetInfo.InjectionType);

											Assert.IsNotNull(targetInfo.InjectionTypeAttributes);
											Assert.AreEqual(1, targetInfo.InjectionTypeAttributes.Count());

											Assert.IsNotNull(targetInfo.InjectionTarget);
											Assert.IsInstanceOfType(targetInfo.InjectionTarget, typeof(PropertyInfo));

											Assert.IsNotNull(targetInfo.InjectionTargetAttributes);
											Assert.AreEqual(1, targetInfo.InjectionTargetAttributes.Count());

											return new BasicService();
										}).As<IBasicService>();

					ioc.ExportFunc((scope, context) => new ImportPropertyService())
						.As<IImportPropertyService>()
						.ImportProperty(x => x.BasicService);
				});

			IImportPropertyService importPropertyService = injectionKernel.Locate<IImportPropertyService>();

			Assert.IsNotNull(importPropertyService);
			Assert.IsNotNull(importPropertyService.BasicService);
		}

		[TestMethod]
		public void ConstructorTargetInfoTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(
				ioc =>
				{
					ioc.ExportFunc((scope, context) =>
										{
											IInjectionTargetInfo targetInfo = context.TargetInfo;

											Assert.IsNotNull(targetInfo);

											Assert.IsNotNull(targetInfo.InjectionType);
											Assert.AreEqual(typeof(ImportConstructorService), targetInfo.InjectionType);

											Assert.IsNotNull(targetInfo.InjectionTypeAttributes);
											Assert.AreEqual(1, targetInfo.InjectionTypeAttributes.Count());

											Assert.IsNotNull(targetInfo.InjectionTarget);
											Assert.IsInstanceOfType(targetInfo.InjectionTarget, typeof(ParameterInfo));

											Assert.IsNotNull(targetInfo.InjectionTargetAttributes);
											Assert.AreEqual(1, targetInfo.InjectionTargetAttributes.Count());

											return new BasicService();
										}).As<IBasicService>();

					ioc.Export<ImportConstructorService>().As<IImportConstructorService>();
				});

			IImportConstructorService importPropertyService = injectionKernel.Locate<IImportConstructorService>();

			Assert.IsNotNull(importPropertyService);
		}

		[TestMethod]
		public void ScopeContextInfoTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			IInjectionScope requestScope = injectionKernel.CreateChildScope();

			injectionKernel.Configure(
				ioc =>
				{
					ioc.ExportFunc((scope, context) =>
										{
											Assert.IsTrue(ReferenceEquals(injectionKernel, scope));

											Assert.IsTrue(ReferenceEquals(requestScope, context.RequestingScope));

											return new BasicService();
										}).As<IBasicService>();

					ioc.Export<ImportConstructorService>().As<IImportConstructorService>();
				});

			IImportConstructorService importPropertyService = requestScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(importPropertyService);
		}

		[TestMethod]
		public void CloneScopeInfoTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				new FauxInjectionScope(),
				null,
				null,
				DependencyInjectionContainer.CompareExportStrategies);

			IInjectionScope cloneScope = null;
			IInjectionScope requestScope = null;

			injectionKernel.Configure(
				ioc =>
				{
					ioc.ExportFunc((scope, context) =>
										{
											Assert.IsTrue(ReferenceEquals(cloneScope, scope), "Should be clone scope");

											Assert.IsTrue(ReferenceEquals(requestScope, context.RequestingScope),
												"Requesting scope incorrect");

											return new BasicService();
										}).As<IBasicService>();

					ioc.Export<ImportConstructorService>().As<IImportConstructorService>();
				});

			cloneScope = injectionKernel.Clone(null, null, null);
			requestScope = cloneScope.CreateChildScope();

			IImportConstructorService importPropertyService = requestScope.Locate<IImportConstructorService>();

			Assert.IsNotNull(importPropertyService);
		}
	}
}