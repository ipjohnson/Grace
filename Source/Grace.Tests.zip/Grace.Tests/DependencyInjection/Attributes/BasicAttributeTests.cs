﻿using Grace.DependencyInjection;
using Grace.DependencyInjection.Impl;
using Grace.UnitTests.Classes.Attributed;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class BasicAttributeTests
	{
		[TestMethod]
		public void BasicServiceTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IAttributeBasicService basicService =
				injectionKernel.Locate<IAttributeBasicService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void ImportCostructorTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IAttributeImportConstructorService basicService =
				injectionKernel.Locate<IAttributeImportConstructorService>();

			Assert.IsNotNull(basicService);
		}

		[TestMethod]
		public void ImportPropertyTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IAttributedImportPropertyService propertyService = injectionKernel.Locate<IAttributedImportPropertyService>();

			Assert.IsNotNull(propertyService);
			Assert.IsNotNull(propertyService.BasicService);
		}

		[TestMethod]
		public void ImportMethodTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IAttributedImportMethodService attributedImport =
				injectionKernel.Locate<IAttributedImportMethodService>();

			Assert.IsNotNull(attributedImport);
			Assert.IsNotNull(attributedImport.BasicService);
		}

		[TestMethod]
		public void ActivationMethodTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IAttributedActivationService activationService =
				injectionKernel.Locate<IAttributedActivationService>();

			Assert.IsNotNull(activationService);
			Assert.IsTrue(activationService.ContextActivationCalled);
			Assert.IsTrue(activationService.SimpleActivationCalled);
		}

		[TestMethod]
		public void ComplexTest()
		{
			InjectionKernelManager manager = new InjectionKernelManager(null,
				DependencyInjectionContainer.CompareExportStrategies,
				new BlackList());
			InjectionKernel injectionKernel = new InjectionKernel(manager,
				null,
				null,
				"RootScope",
				DependencyInjectionContainer.CompareExportStrategies);

			injectionKernel.Configure(c => c.ExportAssembly(GetType().Assembly));

			IComplexService complexService =
				injectionKernel.Locate<IComplexService>();

			complexService.Validate();
		}
	}
}