﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grace.DependencyInjection.Attributes;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class ExportAttributeTests
	{
		[TestMethod]
		public void DefaultAttributeTest()
		{
			ExportAttribute attribute = new ExportAttribute();

			IEnumerable<string> exportNames = attribute.ProvideExportNames(typeof(BasicService));

			Assert.IsNotNull(exportNames);
			Assert.AreEqual(0, exportNames.Count());
		}

		[TestMethod]
		public void NullArgTest()
		{
			try
			{
				ExportAttribute exportAttribute = new ExportAttribute((string)null);

				throw new Exception("ExportAttribute should throw exception on null string");
			}
			catch (ArgumentNullException argumentNull)
			{
				Assert.IsNotNull(argumentNull);
			}

			try
			{
				ExportAttribute exportAttribute = new ExportAttribute((Type)null);

				throw new Exception("ExportAttribute should throw exception on null string");
			}
			catch (ArgumentNullException argumentNull)
			{
				Assert.IsNotNull(argumentNull);
			}
		}

		[TestMethod]
		public void SingleNameAttributeTest()
		{
			const string testExport = "TestExport";
			ExportAttribute attribute = new ExportAttribute(testExport);

			IEnumerable<string> exportNames = attribute.ProvideExportNames(typeof(BasicService));

			Assert.IsNotNull(exportNames);
			Assert.AreEqual(1, exportNames.Count());
			Assert.AreEqual(testExport, exportNames.First());
		}

		[TestMethod]
		public void MultipleNameAttributeTest()
		{
			const string testExport = "TestExport";
			const string secondExport = "SecondExport";
			ExportAttribute attribute = new ExportAttribute(testExport, secondExport);

			IEnumerable<string> exportNames = attribute.ProvideExportNames(typeof(BasicService));

			Assert.IsNotNull(exportNames);
			Assert.AreEqual(2, exportNames.Count());
			Assert.AreEqual(testExport, exportNames.First());
			Assert.AreEqual(secondExport, exportNames.Last());
		}

		[TestMethod]
		public void SingleTypeAttributeTest()
		{
			ExportAttribute attribute = new ExportAttribute(typeof(BasicService));

			IEnumerable<Type> exportTypes = attribute.ProvideExportTypes(typeof(BasicService));

			Assert.IsNotNull(exportTypes);
			Assert.AreEqual(1, exportTypes.Count());
			Assert.AreEqual(typeof(BasicService), exportTypes.First());
		}

		[TestMethod]
		public void MultipleTypeAttributeTest()
		{
			ExportAttribute attribute = new ExportAttribute(typeof(BasicService), typeof(DisposableService));

			IEnumerable<Type> exportTypes = attribute.ProvideExportTypes(typeof(BasicService));

			Assert.IsNotNull(exportTypes);
			Assert.AreEqual(2, exportTypes.Count());
			Assert.AreEqual(typeof(BasicService), exportTypes.First());
			Assert.AreEqual(typeof(DisposableService), exportTypes.Last());
		}
	}
}