﻿using Grace.DependencyInjection.Attributes;
using Grace.DependencyInjection.LifeCycleContainers;
using Grace.UnitTests.Classes.Simple;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class SingletonPerScopeAttributeTests
	{
		[TestMethod]
		public void ProvideLifeCycle()
		{
			SingletonPerScopeAttribute attribute = new SingletonPerScopeAttribute();

			object lifecycle = attribute.ProvideLifeCycle(typeof(BasicService));

			Assert.IsNotNull(lifecycle);
			Assert.IsInstanceOfType(lifecycle, typeof(SingletonPerScopeContainer));
		}
	}
}