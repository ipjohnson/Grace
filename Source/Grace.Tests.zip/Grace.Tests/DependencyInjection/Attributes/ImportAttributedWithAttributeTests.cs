﻿using System.Linq;
using Grace.DependencyInjection;
using Grace.UnitTests.Classes.Attributed;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Grace.UnitTests.DependencyInjection.Attributes
{
	[TestClass]
	public class ImportAttributedWithAttributeTests
	{
		[TestMethod]
		public void ImportMultiple()
		{
			DependencyInjectionContainer container = new DependencyInjectionContainer();

			container.Configure(c => c.ExportAssembly(GetType().Assembly));

			AttributedMultipleSimpleObject multipleSimpleObject =
				container.Locate<AttributedMultipleSimpleObject>();

			Assert.IsNotNull(multipleSimpleObject);
			Assert.IsNotNull(multipleSimpleObject.SimpleObjects);
			Assert.AreEqual(3, multipleSimpleObject.SimpleObjects.Count());
		}
	}
}